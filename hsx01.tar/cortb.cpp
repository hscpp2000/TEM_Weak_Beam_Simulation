#include <iostream>
#include <cmath>

#include <algorithm>
#include <stdio.h>
#include <stdlib.h>

using namespace std;
#include "cplx.h"
#include "vec.h"

void cortb(int & n,Vec & Ar, Vec & Ai,Vec & Zr, Vec & Zi, double * ortr, double * orti)

{
    int i,j,m,la,mm,mp,kp1,mp1;
    double h,gr,gi;
    
    m=n;
 
    la=n-1;
    kp1=2;
    if (la<kp1){cout<<"matrix < 2"<<endl;exit(1);}

    for (mm=kp1;mm<=la;mm++)
    {
        mp=1+n-mm;
        if (Ar(mp,mp-1) ==0 && Ai(mp,mp-1) ==0)continue;
     	h = Ar(mp,mp-1) * ortr[mp] + Ai(mp,mp-1) * orti[mp];
         mp1 = mp + 1;
       
           for(i=mp1;i<=n;i++)
           {
		  ortr[i] = Ar(i,mp-1);
	          orti[i] = Ai(i,mp-1);

        	}
		
	for(j=1;j<=m;j++)
	{
		gr=0;
		gi=0;
		for(i= mp;i<=n;i++)
        	{
		       gr = gr + ortr[i] * Zr(i,j) + orti[i] * Zi(i,j);
               		gi = gi + ortr[i] * Zi(i,j) - orti[i] * Zr(i,j);
		}
		
		gr=gr/h;
		gi=gi/h;
		 for( i = mp;i<= n;i++)
		{
               		Zr(i,j) = Zr(i,j) + gr * ortr[i] - gi * orti[i];
               		Zi(i,j) = Zi(i,j) + gr * orti[i] + gi * ortr[i];
		}


	}






	}

}
