// main program for calculating transmission electron
//microgras based on dynamical scattering theory by Howie et al.
// and elastic theory by Stroh.
//
// In alogorisms the formulas are the forms in the book by
//Hirsch, Howie,.... and Weilan..
//
#include <iostream>
//#include <cstring>
using namespace std;
#include "vec.h"
#include "cplx.h"
#include <cmath>
#include "img.h"
#include <iomanip>

double mode(Vec & v);
Vec rotate(Vec & v);
Vec get_col(int n1,Vec & v);
void exc_c(int n1, int n2, Vec & v);
void exc_r(int n1, int n2, Vec & v);
Vec m3(Vec & v1, const Vec & v2, const Vec & v3);


int main()

{
        int i;
        char par[40];
         nd=0;
        thick=51.2;
	double thinnest=50.;
	double thickest=51.2;
	Vec tr,ti;   
	
 


 
    Vec Beam(1,0,1); 			//beam direction
    Vec u(1,-1,0); 			//dislocation direction
    Vec b(0.5,-.5,0);			//burgers vector
    Vec g(2,0,-2);			//diffraction vector
 
	Vec foil(1,1,2);
	cin>>par>>Beam;
	cin>>par>>u;
	cin>>par>>b;
	cin>>par>>g;
	cin>>par>>foil;
   // Vec cp1,cp2,cp3,cp4: 4 parameters to calculate d(g.R)/dz
  tr=u^(Beam^u);
   ang=(Beam%(u^(Beam^u)))/mode(Beam)/mode(tr);
	
    stroh(Beam,u,b,g,cp1,cp2,cp3,cp4);	// call void sub to produce
					// cp1..., physically,
 
					// but in a much easier way




          Vec OX3=u;
    Vec OX1=Beam^u;
    Vec OX2=OX3^OX1;
    
    OX1=OX1*(1/mode(OX1));
    OX2=OX2*(1/mode(OX2));
    OX3=OX3*(1/mode(OX3));

    Vec DC(9,0);
    DC=m3(OX1,OX2,OX3);

    OX1=-(Beam^u);OX2=-Beam;OX3=OX1^OX2;
    OX1=OX1*(1/mode(OX1));
    OX2=OX2*(1/mode(OX2));
    OX3=OX3*(1/mode(OX3));
    Vec DCX(9,0);
    DCX=m3(OX1,OX2,OX3);

    Vec FN,FNX,BM;
    FN=DC*foil; FN=FN*(1./mode(FN));
    FNX=DCX*foil;FNX=FNX*(1./mode(FNX));
    BM=DC*Beam;      BM=BM*(1./mode(BM));
       
     cin>>par>>nd;  //beam number
     Vec Ar,Ai;     //complex matrix of potentials
    gvec=Vec(nd,0);    
    cin>>par>>gvec;
    Wr=Vec(nd-1,0); Wi=Vec(nd,0); //eigenvalues    
    Zr=Vec(nd-1,0); Zi=Vec(nd,0);     // eigen vectors
      cin>>par>>Wr;Wr=Wr*2;
     cin>>par>>Wi;
     cin>>par>>Zr;Zr=Zr*2;
      cin>>par>>Zi[0];Zi=Vec(nd,Zi[0]);
	cin>>par>>thinnest;
	cin>>par>>thickest;

        Ar=m2(Wr,Wi);
      Ai=m2(Zr,Zi);
 
   exc_r(1,2,Ar);exc_c(1,2,Ar);exc_r(2,3,Ar);exc_c(2,3,Ar);
     exc_r(1,2,Ai);exc_c(1,2,Ai);exc_r(2,3,Ai);exc_c(2,3,Ai);

	//(Ar*2).show();Ai.show();exit(1);
      Cr=Ar;
    Wr=Vec(nd,0); Wi=Vec(nd,0);Zr=Vec(nd*nd,0);Zi=Vec(nd*nd,0);

    rs(nd,Ar,Wr,Zr);
   // cg(nd, Ar, Ai,Wr, Wi,Zr, Zi);  //finding eigenvalues/vectors
    Zi=((rotate(Zr))*Ai*Zr);
      for(i=1;i<=nd;i++)
      Wi[i-1]=Zi(i,i);
    Zi=rotate(Zr);
 //   (Cr*Zr).show();(Zr|Wr).show();
    
  
    Wr=Wr*(2*pi);Wi=Wi*(2*pi);
    



        gvec[0]=0.;gvec[1]=1.;gvec[2]=-1.;
        gvec[3]=2.;gvec[4]=3.;gvec[5]=4.;            
    br=bi=Vec(nd,0);

   // Cr=Zr;Ci=Zi;
    //complex_inv(Cr,Ci);
      //  br0=get_col(1,Cr);
        bi0=Vec(nd,0);
     br0=get_col(1,Zi);
	//br0=br0*(-2*pi);bi0=bi0*(2*pi);

          Ar=Vec(nd,0);
	Ai=Vec(nd,0);
	int i1;
    double back=1.;


    int j=0;
    u0=0;
    
  if(ang!=0)
    tang=sqrt(1.-ang*ang)/ang;
    else {cout<<" the dislocation is pararell to the beam";exit(1);}
    if (ang!=1)
    length=.5*(thickest+thinnest)/tang;
    else length=2.*thick;

//    length=thinnest*BM[1]/FN[2];


	width=0.5*length;
    dx=width/double(row);
     double w2=width*.5;	
  //  tang=FN[2]/BM[1];
//	u1=0.5*thinnest/tang;
        u1=0.5*(thickest-thinnest)/length;

    //ang=1/(tang*tang+1);
   // ang=sqrt(ang);
	  double FNBM;FNBM=(FN%BM)/mode(FN)/mode(BM);
    	double    fnx=1-FNX[0]*FNX[0];
	 fnx=sqrt(fnx);
	cout<<thinnest;exit(1);

while (u0<length)
    {

        
	thick=thinnest+(thickest-thinnest)/512.*double(j);

//	   thick=thick/FNBM;
	u0=length/512.*double(j+1);
//	thick=thinnest+u1*u0;
//        j++;cout<<j<<" "<<thick<<" "<<u0<<endl;continue;
	for(i1=0;i1<nd;i1++)
	{

		Ar[i1]=cos(Wr[i1]*thick)*exp(-Wi[i1]*thick);
		Ai[i1]=sin(Wr[i1]*thick)*exp(-Wi[i1]*thick);
	}

//	tr=(Zr|Ar)-(Zi|Ai);
//	ti=(Zr|Ai)+(Zi|Ar);
        tr=Zr|Ar;
        ti=Zr|Ai;
      
    

    for(i=0;i<row;i++)
    {
   
            x=-(w2-(double)(i)*dx);
//	x=-(w2-(double)(i)*dx);


        if(i==0 && j==0)x=1000.;
         ing();

	Ar=(tr*br)-(ti*bi);
	Ai=(tr*bi)+(ti*br);
	br=(Ar&Ar)+(Ai&Ai);
     if(i==0 && j==0) back=br[0];
        if(i==0 && j==0) continue;
     
        cout<<setw(14)<<br[1]/back;



      
            
 
    }

    cout<<endl;
    j++;
    }


 return 0;
}


