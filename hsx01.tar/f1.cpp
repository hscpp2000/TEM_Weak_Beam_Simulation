#include <iostream>
using namespace std;
#include <cmath>
#include "vec.h"
#include "cplx.h"
#include "ing2.h"
#include "StiffIntegratorT.h"
#include "NonStiffIntegratorT.h"
#include "decsol.h"


extern void fx(Vec & v1, Vec & v2, double x, double y);
void Function (double z,double * Fx, double *f,double x)
{
Vec Cr,Ci;
Cr=Ci=Vec(nd*nd,0);
int i=0;

Vec Fr,Fi,fxr,fxi; Fr=Fi=fxr=fxi=Vec(nd,0);




	for(i=0;i<nd;i++) 
	{Fr[i]=Fx[i];Fi[i]=Fx[i+nd];}

        fx(Cr,Ci,z,x);
	fxr=Cr*Fr-Ci*Fi;	
	fxi=Cr*Fi+Ci*Fr;
	
 for(i=0;i<nd;i++) {f[i]=fxr[i];f[i+nd]=fxi[i];}
	

}





