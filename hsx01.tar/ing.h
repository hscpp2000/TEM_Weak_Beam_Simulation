#ifndef _IMG_H_
#define _IMG_H_
#include "vec.h"


extern Vec Wr,Wi,Zr,Zi,Cr,Ci,br,bi,br0,bi0;
extern  double ang,thick,x,u0,tang,u1,length;
extern double c1,c2,c3,c4,tFNBM;
extern  int nd;
extern  Vec cp1,cp2,cp3,cp4;
double ht2;
extern Vec gvec;
const double pi=3.1415926535897932384626433832795;

void derivs(double z, double * y, double * y2,double * dydz,double * dydz2);
void rkqs(double * y, double * y2,double * dydz, double * dydz2,
int & nvar,double & z ,double & h,
double & eps, double * yscal, double * yscal2,double & hdid, double & hnext);
void rkck(double * y,double * y2,double * dydz,
double * dydz2,int & n,double & z,
double & h, double * yout,double * yout2,double * yerr, double * yerr2);
double drdz(Vec v1,Vec v2, Vec v3, Vec v4,double & x,double & y);

//double gr(Vec & v1,Vec & v2,Vec & v3, Vec & v4,double & x,double & y);

//void derivs(double z,double * Br,double * Bi,double * fr,double * fi);
 



#endif

