// This is an adaptive stepsize control program
//gr=d(g.r)/dz

#include <iostream>
using namespace std;
#include <cmath>
#include "vec.h"
#include "cplx.h"
#include "ing2.h"
#include "StiffIntegratorT.h"
#include "NonStiffIntegratorT.h"
#include "decsol.h"


//double gr(Vec  v1,Vec  v2,Vec  v3, Vec  v4,double & x,double & y);
Vec derivs4(double  z,double x);
void fx(Vec & Cr,Vec &Ci,double x,double y);
void fx2(Vec & Cr,Vec &Ci,double x,double y);
//Vec inv(Vec  v);
//void Function (double z, double *Fx, double *f,double x);
//void Jacobian (double z,double *Fx, double **J);
void Mass(double **M);

void ingfault(Vec& br,Vec& bi, double& x)

{


    double z1,z2,z;
    int i,i1;
        i=0;
    

	z2=thick;z1=0;



    Vec Fr(nd,0);Vec Fi(nd,0);
    
    


    br=bi=Vec(nd,0);
    br[0]=1.0;
    Fr=Zi*br;Fi=Vec(nd,0);

    
	int n; n=2*nd;
	double* Fx=new double [n];
	//double y[n] = {2.0, 0.0};
	for(i1=0;i1<nd;i1++) {Fx[i1]=Fr[i1];Fx[i1+nd]=Fi[i1];}
	// initial value for z (x)
	double xbeg = z1;
	// final value for x
	 double xend= z2;
	// interval of x for printing output
	double dx = .5;
	// rtoler and atoler are scalars
	int itoler = 0;
	// relative tolerance
	double *rtoler = new double(dz);
	// absolute tolerance
	double *atoler = new double(dz);
	// use SolutionOutput routine
	const int iout = 1;
	// initial step size
	double hinit = 0.6;
	// analytical Jacobian function provided
	const int ijac = 1;
	// number of non-zero rows below main diagonal of Jacobian
	int mljac = n;
	// number of non-zero rows above main diagonal of Jacobian
	int mujac = n;
	// Mass matrix routine is identity
	const int imas = 0;
	int mlmas = 0;
	int mumas = 0;
	
	// Use default values (see header files) for these parameters:
	double hmax(0.0);
	int nmax(0);
	double uround(0.0), safe(0.0), facl(0.0), facr(0.0);
	int nit(0);
	bool startn(false);
	int nind1(0), nind2(0), nind3(0), npred(0), m1(0), m2(0);
	bool hess(false);
	double fnewt(0.0), quot1(0.0), quot2(0.0), thet(0.0);

	if (stiff==1)
	{
	
//	    cout<<"Using Stiff_Integrator for HW equations"<<endl;
	StiffIntegratorT stiffT(n,x, Fx, xbeg, xend, dx, itoler, rtoler, atoler,
		iout, hinit, hmax, nmax, uround, safe, facl, facr, ijac, mljac,
		mujac, imas, mlmas, mumas, nit, startn, nind1, nind2, nind3, npred,
				m1, m2, hess, fnewt, quot1, quot2, thet);

	stiffT.Integrate();}


	const int iout2 = 2;
	hinit = 0.0;
	double beta = 0.0;
	int nstiff = 0;
	int nrdens = n;
	unsigned *icont = NULL;
	if(stiff==0)
	{
//	    cout<<"Using Non_Stiff Interator for HW equations"<<endl;
	NonStiffIntegratorT nonstiffT(n, x,Fx, xbeg, xend, dx, nrdens, itoler, rtoler,
		atoler, iout2, hinit, hmax, nmax, uround, safe, facl, facr, beta,
		nstiff, icont);

	nonstiffT.Integrate();
/*
	cout << "fcn = " << nonstiffT.NumFunction() <<
		    " step = " << nonstiffT.NumStep() <<
			" accpt = " << nonstiffT.NumAccept() <<
			" rejct = " << nonstiffT.NumReject() << endl;*/
}

	delete rtoler;
	delete atoler;


	for(i1=0;i1<nd;i1++) {Fr[i1]=Fx[i1];Fi[i1]=Fx[i1+nd];}
	
	delete [] Fx;
	


	br=Zr*Fr;bi=Zr*Fi;

}




void Mass(double **M)
{


}
void fx2(Vec &Cr,Vec &Ci,double z,double x)
{
  Vec Gr(nd*nd,0);
Gr=derivs4(z,x);//d(g.r)/dz


	Ci=(Ar+Gr)*(2*pi);
	Cr=Ai*(-2*pi);



}

void fx(Vec &Cr,Vec &Ci,double z,double x)
{
    Vec Gr(nd*nd,0);
    Vec Gi(nd*nd,0);
    Vec Pr(nd*nd,0);
    Vec Pi(nd*nd,0);
        int i1=0;

// calculation of Gr=exp{-2pigamma}z
  for(i1=0;i1<nd;i1++)
      {  Gr[(nd+1)*i1]=cos(Wr[i1]*z*(-2)*pi)*exp(2*pi*Wi[i1]);
      Gi[(nd+1)*i1]=sin(Wr[i1]*z*(-2)*pi)*exp(2*pi*Wi[i1]);}



    Pr=Gr*Zi;//Gamma*C-1
    Pi=Gi*Zi;

	Gr=Gr*0;	
        Gr=derivs4(z,x);//d(g.r)/dz

        Pr=Pr*Gr;
        Pi=Pi*Gr;
        Pr=Pr*Zr;
        Pi=Pi*Zr;

  for(i1=0;i1<nd;i1++)
  {  Gr[(nd+1)*i1]=cos(Wr[i1]*z*2*pi)*exp(-2*pi*Wi[i1]);
          Gi[(nd+1)*i1]=sin(Wr[i1]*z*2*pi)*exp(-2*pi*Wi[i1]);}





        Ci=(Pr*Gr-Pi*Gi)*(2*pi);


        Cr=(Pr*Gi+Pi*Gr)*(-2*pi);


}


Vec derivs4(double  z,double x)
{
    int i1=0;
    double y,y0,y1,y2,y3;
    double tFNBM=bFNBM/FNBM;
    double ymin=0;
    int iz=0;
    
    
 if (ang==1.)
   {

       y=thick-.5*FNBM*thick+u0*u1*.5-z;
   }
    else
  {


      y=ang*(thick-z-u0*tang/FNBM);

 }

       y0=y;
       y=y0+pt1;
       y1=y0+pt2;
       y2=y0-pt2;
       y3=y0+pt3;


       double Beta=0;

       Vec Gr(nd*nd,0);
    int ip=0;
    double Beta1=0;


        double x1a,x1b,x1c,x1d;

        x1a=-(dc1+0.5*da);
        x1b=-(0.5*da);
        x1c=0.5*da;
        x1d=dc2+0.5*da;



             for (i1=0;i1<nd;i1++)
             {
	       if(x<x1a  && fabs(y0)<0.4 && iz==0)
		  Beta=R1*gvec[i1];
                


          	if(x>x1a && x<1b && fabs(y0)<0.4 && iz==0)
		  Beta=R2*gvec[i1];
                                
                if(x>x1b && x<1b && fabs(y0)<0.4 && iz==0)
		  Beta=R3*gvec[i1];

                if(x>x1c && x<1d && fabs(y0)<0.4 && iz==0)
		  Beta=R4*gvec[i1];

		if(x>x1d  && fabs(y0)<0.4 && iz==0)
		  Beta=R5*gvec[i1];
                

		


               Gr[(nd+1)*i1]=Beta;

	                     

            }
	     if(Beta!=0){iz=1;Beta=0;)

             return Gr;

}

