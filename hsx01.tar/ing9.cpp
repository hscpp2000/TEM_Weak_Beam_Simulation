// This is an adaptive stepsize control program
// using Runge-Kutta method, surprisingly fast! and accurate!!!

#include <iostream>
using namespace std;
#include <cmath>
#include "vec.h"
#include "cplx.h"
#include "ing2.h"




//double gr(Vec  v1,Vec  v2,Vec  v3, Vec  v4,double & x,double & y);
void derivs9(double  z, Vec & fr, Vec & fi,Vec Pr,Vec Pi,int & ks, double& x);
//Vec rotate(Vec & v);
//void complex_inv(Vec & v1, Vec & v2);


void ingfault(Vec& br,Vec& bi, double& x)

{

    Vec Gr(nd,0);
    Vec Gi(nd,0);
    Vec Pr(nd*nd,0);
    Vec Pi(nd*nd,0);
    double z1,z2,z;



    int i,i1;
    Vec fr(nd*nd,0);Vec fi(nd*nd,0);


    z2=u0*u1;z1=-(thick-u0*u1);
    z2=thick;z1=0;
//  double xa,xb,xc,xd,br0,bi0,Beta1;Beta1=0;
	if(dz==0.)dz=0.5;
	dz=.001*z2;
        int nstep=int(thick/dz);

    br=bi=Vec(nd,0);
    br[0]=1.0;
    Vec Br(nd,0);Vec Bi(nd,0);
	z=z1+dz;
    for(i1=0;i1<nd;i1++)
        {  Gr[i1]=cos(Wr[i1]*dz*2*pi)*exp(-Wi[i1]*dz*2*pi);
                 Gi[i1]=sin(Wr[i1]*dz*2*pi)*exp(-Wi[i1]*dz*2*pi);}





    Pr=(Zr|Gr)*Zi;
    Pi=(Zr|Gi)*Zi;
//  xa=-abs(dc1+0.5*da);xb=-.5*abs(da);
    //xd=0.5*abs(da+dc2); xc=-xb;
    //c P1r,P1i;
    //r=Pr;P1i=Pi;
	int iz=0;
    for(i=1;i<=nstep;i++)
    {
        z=z+dz;



	derivs9(z,fr,fi,Pr,Pi,iz,x);//f=Pn=Qn-1PQn 

	Br=fr*br-fi*bi;
	Bi=fi*br+fr*bi;

        br=Br;bi=Bi;



        
    }



    fr=(Pr*br)-(Pi*bi);
      fi=(Pr*bi)+(Pi*br);

    br=fr;bi=fi;



    

}


   	
void derivs9(double  z, Vec & fr, Vec & fi,Vec Pr, Vec Pi,int & iz,double& x)
{
    int i1=0;
    double y,y0;
double y1,y2,y3;
 double ymin=0; 
 double tFNBM=bFNBM/FNBM;
 if (ang==1.)
   {
       // y=-FNBM*(z+.5*thick);
       y=c3-z;
       ymin=-1;
   
   }
    else
  {
   
//    y=(u0*(tFNBM+tang)/(1-tFNBM*tang)-u0*tFNBM+z)*(FNBM*ang-bFNBM*bng);
y=s4*(c2-z);
 ymin=-s4; 
  
    
 } 
 y0=y;
 y=y0+pt1;
 y1=y0+pt2;y2=y0-pt2;
 y3=y0+pt3;

    double x1=-x;

    double Beta=0.;
	
    cplx c1;
    Vec Qr(nd,0);
      Vec Qi(nd,0);
    Vec Qinvr(nd,0);
    Vec Qinvi(nd,0);
    Vec tr(nd*nd,0);Vec ti(nd*nd,0);

	double b1,b2,b3,b4; b1=b2=b3=b4=0;
	double x1a,x1b,x1c,x1d;

    x1a=-(dc1+0.5*da);
    x1b=-(0.5*da);
    x1c=0.5*da;
    x1d=-x1a;



             for (i1=0;i1<nd;i1++)
             {
                



//	        Beta=b1+b2+b3+b4;//Beta=Beta*2*pi;




	 if(x1<x1a && (y0-ymin)<.2 && iz==0){Beta=(R1)*gvec[i1];}
        if(x1>x1a && x1<x1b && (y-ymin)<.2 && iz==0){Beta=(R2)*gvec[i1];}
	if(x1>x1b && x1<x1c && (y1-ymin)<.2 && iz==0){Beta=(R3)*gvec[i1];}
	if(x1>x1c && x1<x1d && (y2-ymin)<.2 && iz==0){Beta=(R4)*gvec[i1];}
	if(x1>x1d && (y3-ymin)<.2 && iz==0){Beta=(R5)*gvec[i1];}
 

   if(Beta!=0)
		{

		Qr[i1]=cos(Beta);
		Qi[i1]=sin(Beta);
		    c1=cplx(1,0)/cplx(Qr[i1],Qi[i1]);
		    Qinvr[i1]=c1.get_real();
                    Qinvi[i1]=c1.get_img();
		}
           }


	    
if(Beta!=0)

          {


	
    tr=(Qinvr|Pr)-(Qinvi|Pi);
    ti=(Qinvr|Pi)+(Qinvi|Pr);
    fr=(tr|Qr)-(ti|Qi);
    fi=(tr|Qi)+(ti|Qr);
 
    iz=1;
    Beta=0;

	  }

 else
{fr=Pr;fi=Pi;}
}








 





