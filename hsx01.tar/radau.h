#ifndef _IMG_H_
#define _IMG_H_
extern X2;




#endif
