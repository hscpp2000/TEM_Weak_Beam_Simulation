#include <iostream>
#include <cmath>
using namespace std;
#include "cplx.h"


cplx::cplx()
{
real=img=0;
}

cplx::cplx(const double & x,const double & y)
{
    real=x;img=y;    
}


cplx::cplx(const cplx & c)

{
    real=c.real;img=c.img;
}

cplx::~cplx()
{

}




double cplx::modulus()
{
   return sqrt(real*real+img*img);
}

cplx  cplx::operator+(const cplx & c) const
{
    return cplx(real+c.real,img+c.img);

}


cplx cplx::operator-(const cplx & c) const
{
    return cplx(real-c.real,img-c.img);
           
}

cplx cplx::operator-() const
{
  
     return cplx(-real,-img);
}                                                       

cplx cplx::operator*(const cplx & c) const
{
    return cplx(real*c.real-img*c.img,real*c.img+c.real*img);
}

bool  cplx::operator==(const cplx & c) const
{
	if(c.real==real && c.img==img)
	return true;
	else return false; 
}

bool  cplx::operator!=(const cplx & c) const
{
	if(c.real!=real || c.img!=img)
	return true;
	else return false; 
}


cplx cplx::operator/(const cplx & c) const
{
    return cplx((real*c.real+img*c.img)/(c.real*c.real+c.img*c.img),
            (c.real*img-real*c.img)/(c.real*c.real+c.img*c.img));
}


cplx cplx::operator^(const int & n) const

{
  int i;
  cplx temp(1,0);
  for (i=0;i<=n;i++)
    if (i==0)
  temp=cplx(1,0);
  else
  temp=temp**this;
  return temp;
    
}  



ostream & operator<<(ostream & os, const cplx & c)
{
    os<<"(";
 os<<c.real<<"+ i"<<c.img;
    os<<")\n";
   return os;  
    

}

cplx & cplx::operator=(const cplx & c)
{
    
    if (this==&c)
    return *this;
    
   real=c.real;img=c.img;
    return *this;
}

double & cplx::get_real()
{
    return real;
}

double &  cplx::get_img()
{
    return img;
}

cplx cplx::conj()
{
    return cplx(real,-img);
}    


