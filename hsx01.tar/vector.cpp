#include <iostream>
#include <cmath>
#include <algorithm>
#include <stdio.h>
#include <stdlib.h>
using namespace std;
#include "vec.h"
#include <iomanip>

static const double zero=0;
/* class Vec constructor
examples:
Vec beam; //default having beam(0)=beam(1)=beam(2)=0
Vec beam(0,0,1); //initialised
Vec DC(9,0);//initialised with '0'
beam=Wi=Vec(nd,0);//beam reinitialised became nd elements
double *pt=new double [n];
beam=Vec(pt,n);// 

  */

double det(Vec  v);
Vec cofactor(Vec  v);
Vec inv(Vec  v);

Vec::Vec()
{
   size=3;
   cube=new double[size];
    cube[0]=cube[1]=cube[2]=0;
}

Vec::Vec(const double & a,const double & b, const double & c)
{
    size=3;
    cube=new double[size];
    cube[0]=a;
    cube[1]=b;
    cube[2]=c;
    
}

Vec::Vec(const double * pt,const unsigned & n)
{
    size=n;
    cube=new double[size];
    for (unsigned int i=0;i<n;i++)
    cube[i]=pt[i];
}

Vec::Vec(unsigned n, double  val)
{
    size=n;
    cube=new double[size];
    for (unsigned int i=0;i<size;i++)
    cube[i]=val;
}

Vec::Vec(const Vec & v)

{
    size=v.size;
    cube=new double[size];
        for (unsigned int i=0;i<size;i++)
    cube[i]=v.cube[i];
}


Vec::~Vec()
{
   delete [] cube;
}


// Vec A, B, C     C=A+B;
Vec  Vec::operator+(const Vec & v) const
{
   unsigned int i;
    if(size==v.size)
  {

  Vec temp(size,0);
    for ( i=0;i<size;i++)
   temp.cube[i]=cube[i]+v.cube[i];
    return temp;
  }
  if(size>v.size)
  {
    
	  Vec temp(size,0);
   temp=*this;
    for (i=0;i<v.size;i++)
    temp.cube[i]=temp.cube[i]+v.cube[i];
    return temp;
  }
    else
  {
   Vec  temp(v.size,0);
    
    temp=v;
    for (i=0;i<size;i++)
    temp.cube[i]=temp.cube[i]+cube[i];
    return temp;
  }
  cout<<'matrix olus failed';exit(1);
}

//Vec A, B,C; C=A-B;
Vec Vec::operator-(const Vec & v) const
{
  if(size!=v.size)
  {cout<<"sorry wrong!"<<endl;exit(1);}
  Vec temp(size,0);
    for (unsigned int i=0;i<size;i++)
   temp.cube[i]=cube[i]-v.cube[i];
    return temp;
           
}

 //elecment inverse
Vec Vec::operator-() const
{
  
  
  Vec temp(size,0);
    for (unsigned int i=0;i<size;i++)
   temp.cube[i]=-cube[i];
    return temp;
}                                                       

//matrix X
Vec Vec::operator*(const Vec & v) const
{
    unsigned int i,j,k;
    unsigned int l=0;
    double sum=0;
    int nsize=100;
    float at0;
    at0=sqrt((float)size);
    nsize=(int)at0;
    
      if(size==v.size)
     {
     unsigned   int n=nsize;

        Vec temp(size,0);
            for(i=0;i<n;i++)
            {
                for(j=i;j<i+n;j++)
                {
                    for(k=0;k<n;k++)
                        {
                        sum=sum+cube[n*i+k]*v.cube[n*k+l];
                  
                        }


                    temp.cube[(n-1)*i+j]=sum;
                    sum=0;
                    
                   l++;
                }
                l=0;
            }    
                return temp;
         }    
    if (size<v.size && size==(unsigned int)sqrt((float)v.size))
    {
            Vec temp(size,0);
        for (i=0;i<3;i++)
            {
                for (j=0;j<size;j++)
                sum=sum+cube[j]*v.cube[size*j+i];
            temp.cube[i]=sum;
            sum=0;
            }

            return temp;
    }
    if (size>v.size && v.size==(unsigned int)sqrt((float)size))
    {
            Vec temp(v.size,0);
        for (i=0;i<v.size;i++)
            {
                for (j=0;j<v.size;j++)
                sum=sum+v.cube[j]*cube[v.size*i+j];

               
            temp.cube[i]=sum;
            sum=0;
            }

            return temp;
    }
    cout<<"matrix not operatable [1 x n][n x n]=n failed"<<endl;
    exit(1);
}

//Vector cross x
Vec Vec::operator^(const Vec & v) const

{
    if (size!=3){cout<<"meaningless! Only for Vecotr A x vector B"<<endl;exit(1);}            

   return Vec (cube[1]*v.cube[2]-cube[2]*v.cube[1],
   cube[2]*v.cube[0]-cube[0]*v.cube[2],
   cube[0]*v.cube[1]-cube[1]*v.cube[0]);
    
}  

//vector point X
double Vec::operator%(const Vec & v) const                                                    
{
        if (size!=3){cout<<"meaningless! Only for A*B"<<endl;exit(1);}            
    return (cube[0]*v.cube[0]+cube[1]*v.cube[1]
    +cube[2]*v.cube[2]);
}

//Vec time a constant
Vec Vec::operator*(const double & a) const
{
       unsigned int i;
       Vec temp(size,0);
       for (i=0;i<size;i++)
       temp.cube[i]=cube[i]*a;
    
    return temp;
}

//const double  & Vec::operator[](int i) const
//make a vector a form of array a[0],...a[n]
double  & Vec::operator[](int i) const
{
    return cube[i];
}

//a n x n matrix a(1,1),... a(n,n)
double & Vec::operator()(int i, int j)
{
	int i1,j1,n,m;
	n=int(sqrt((float)size));
	m=0;
	for (i1=0;i1<n;i1++)
	for(j1=0;j1<n;j1++)
	{
	if(i1==i-1 && j1==j-1)
	return cube[m];
	m++;
	}
	cout<<" wrong requirement for matrix";
	exit(1);
}
//4th tensor elecment C(1,2,1,4)
double & Vec::operator()(int i, int j,int k, int l)
{
		int i1,j1,k1,l1,m;m=0;
		for (i1=0;i1<3;i1++)
		  for (j1=0;j1<3;j1++)
		    for (k1=0;k1<3;k1++)
			for (l1=0;l1<3;l1++)
			{
			if (i1==i-1 && j1==j-1 && k1==k-1 && l1==l-1)
			return cube[m];
			m++;
			}
	cout<<"no tensor element found";
	  exit(1);
}


//print Vec in a form of [a,...f] cout<<A;
ostream & operator<<(ostream & os, const Vec & v)
{
	  
  os<<"[";
for (unsigned int i=0;i<v.size;i++)
 os<<v.cube[i]<<",";
    os<<"]\n";
   return os;  
    

}
//input by keyboard  cin>>
istream & operator>>(istream & is,  Vec & v)
{
    int n,i;
    n=v.size;
    for (i=0;i<n;i++)
    is>>v.cube[i];
    return is;
}

Vec & Vec::operator=(const Vec & v)
{
    if(size!=v.size)
    {size=v.size;} 
    if (this==&v)
    return *this;
    delete [] cube;
   
    cube=new double[size];
    for(unsigned int i=0;i<size;i++)
    {

	cube[i]=v.cube[i];
	}
    return *this;
}





Vec Vec::operator/(const Vec & v) const
{
    Vec temp(size+v.size-1,0);
    unsigned int i,j;
    for (i=0;i<size;i++)
    for (j=0;j<v.size;j++)
    temp.cube[i+j]=temp.cube[i+j]+cube[i]*v.cube[j];

    return temp;
}

unsigned int Vec::len()
{
    return size;
}

Vec Vec::operator&(const Vec & v) const

{
    Vec temp(size,0);
    int n=size;
    int i;
    for (i=0;i<n;i++)
    temp.cube[i]=cube[i]*v.cube[i];
    return temp;
}

Vec Vec ::operator|(Vec & v)
{
    int n,i,j;
    Vec t;
    if (size<v.size)
    {
        n=size;
        t=Vec (v.size,0);
        for( i=0;i<n;i++)
        for (j=0;j<n;j++)
        t[i*n+j]=v.cube[i*n+j]*cube[i];

    }
    else
    {
                n=v.size;
        t=Vec (size,0);
        for( i=0;i<n;i++)
        for (j=0;j<n;j++)
        t[i*n+j]=cube[i*n+j]*v.cube[j];

    
    }

    return t;
}


void Vec::show()
{
   int n=(int)sqrt((float)size);
   
    int i,j;
    for (i=0;i<n;i++)
    {cout<<"|";
    for( j=0;j<n;j++)
    cout<<setw(12)<<setprecision(7)<<cube[n*i+j]<<" ";
    cout<<"|"<<endl;
    }
    cout<<endl;    
}


//matrix inverse
Vec inv(Vec  v)
{
    unsigned    int n=(int)sqrt(v.len());
        if((double) n!=sqrt(v.len()))
            {
                cout<<"Matrix is not n x n";
                exit(1);
            }
            //double (*t1)[20]=new double[20][20];
		Vec t1(400,0);
         unsigned   int i,j,m; m=0;
             long double a;


            for (i=0;i<n;i++)
                for(j=0;j<n;j++)
                {
                    t1(j+1,i+1)=v[m];
                    m++;
                }
                Vec temp(v.len(),0);
                    m=0;
                  for (i=0;i<n;i++)
                for(j=0;j<n;j++)
                {
                  temp[m]=t1(i+1,j+1);
                    m++;  
                }

                a=det(temp);

                temp=cofactor(temp);

                a=1/a;

                temp=temp*a;

                return temp;
}

double det(Vec  v)
{
 int n=(int)sqrt(v.len());
        if((double) n!=sqrt(v.len()))
            {
                cout<<"Matrix is not n x n no det!";
                exit(1);
            }
               // double (*t1)[20]=new double[20][20];
                Vec t1(400,0);
                int i,j,m;m=0;
                for (i=0;i<n;i++)
                    for(j=0;j<n;j++)
                        {
                            t1(i+1,j+1)=v[m];
                            m++;
                        }
               Vec t2(20,0);
                 double a=0;
                double s=1;
                 double a1=1;
                a=t1(1,1);
                while(n!=1)
               {
                    s=1;
                    while (t1(1,1)==0)
                    {
                        for (i=1;i<n;i++)
                     
                            if (t1(1,i+1)!=0 && t1(1,1)==0)
                             {
                              for(j=0;j<n;j++)
                                  {
                                   a=t1(j+1,1);
                                   t1(j+1,1)=t1(j+1,i+1);
                                   t1(j+1,i+1)=a;
                                 }
                              a=t1(1,1);
                              s=-1;
                             }

                            if (t1(1,1)==0)
                                {
                                  a1=0;
		          	
                                 return a1;
                                }
                       
                    }
                  
                    
                     for (i=1;i<n;i++)
                    t2[i]=-t1(i+1,1)/t1(1,1);

                    for (i=1;i<n;i++)
                    for (j=0;j<n;j++)
                     t1(i+1,j+1)=t1(i+1,j+1)+t2[i]*t1(1,j+1);
                    

                    

                    for (i=0;i<n-1;i++)
                    {
                        for (j=0;j<n-1;j++)
                        {
                         t1(i+1,j+1)=t1(i+2,j+2);
                         
                        }
                        
                    }
                    a1=a1*t1(1,1)*s;
                    n=n-1;

                  
                    
                }
             

            return a1*a;
}

Vec cofactor(Vec  v)
{
     int n=(int)sqrt(v.len());
        if((double) n!=sqrt(v.len()))
            {
                cout<<"Matrix is not n x n";
                exit(1);
            }
                //double (*t1)[20]=new double [20][20];
		//double (*t2)[20]=new double [20][20];
		Vec t1(40,0);
		Vec t2(40,0);
                int i,j,i1,j1,m1,m;m=m1=0;
                Vec temp((n-1)*(n-1),0);
                
                for (i=0;i<n;i++)
                    for(j=0;j<n;j++)
                        {
                            t1(i+1,j+1)=v[m];
                            m++;
                        }
                        m=0;
               for (i=0;i<n;i++)
                    for(j=0;j<n;j++)
                        {
                         for (i1=0;i1<n;i1++)
                            for(j1=0;j1<n;j1++)
                                if(i1!=i && j1!=j)
                                {
                                    temp[m]=t1(i1+1,j1+1);
                                    m++;
                                }
                                m=0;
                                if(double(i+j)/2.==double((i+j)/2))
                           t2(i+1,j+1)=det(temp);
                            else
                            t2(i+1,j+1)=-det(temp);
			}
			m=0;
		Vec temp1(v.len(),0);
                    for(i=0;i<n;i++)
                    for (j=0;j<n;j++)
                    {

                    temp1[m]=t2(i+1,j+1);
                    m++;
		    }
	
    return temp1;	
}







