#include <iostream>
using namespace std;
#include "vec.h"
#include "cplx.h"

#include <algorithm>
#include <stdio.h>
#include <stdlib.h>

#include <cmath>
void newton(Vec & v1, Vec & v2,cplx & z)
{
     int n,i,m;
   const double error=1e-15;
    n=v1.len();m=0;

    cplx fz,fzb,ze;
    double a1,a2,a3;a1=a2=.1;
    a3=1.0;
    while(a3>error) 
    {
            if(m>1000){cout<<"iteration over 1000 failed";exit(1);}
        fz=cplx(0,0);fzb=cplx(0,0);
          for (i=0;i<n;i++)
        {
            fz=fz+cplx(v1[i],v2[i])*(z^i);
            fzb=fzb+cplx(i,0)*cplx(v1[i],v2[i])*(z^((i-1)));
           
        }
    
      
        ze=fz/fzb;
        z=z-ze;
        a1=ze.modulus()*ze.modulus();
        a2=z.modulus()*z.modulus();
    	a3=a1/a2;
        m++;
    
    }
    
    m=0;
    fz=cplx(v1[n-1],v2[n-1]);
    double * t1=new double[n-1];
    double * t2=new double[n-1];

    for(i=0;i<n-1;i++)
    {
        m=n-2-i;
        
        t1[m]=fz.get_real();
        t2[m]=fz.get_img();
        fz=fz*z+cplx(v1[m],v2[m]);
    }
        v1=Vec(t1,n-1);
        v2=Vec(t2,n-1);

}

