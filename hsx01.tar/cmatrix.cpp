#include <iostream>
#include <cmath>
using namespace std;
#include "vec.h"
#include "cplx.h"

cplx complex_det(Vec v1, Vec v2);
void complex_cofactor(Vec & v1, Vec & v2);
//void complex_inv(Vec & v1, Vec & v2);
Vec rotate(Vec & v);

cplx complex_det(Vec  v1, Vec  v2)
{
		int n=int(sqrt((float)v1.len()));

		cplx (*t1)[18]=new cplx [18][18];
                
                int i,j,m;m=0;
                for (i=0;i<n;i++)
                    for(j=0;j<n;j++)
                        {
                            t1[i][j]=cplx(v1[m],v2[m]);
                            m++;
                        }
               cplx* t2=new cplx [n];
               cplx a=cplx(0,0);
                cplx s=cplx(1,0);
                cplx a1=cplx(1,0);
                a=t1[0][0];
		cplx cplx_zero=cplx(0,0);
                while(n!=1)
		
               {
                    s=cplx(1,0);
                    while (t1[0][0]==cplx_zero)
                    {
                        for (i=1;i<n;i++)
                     
                     if (t1[0][i]!=cplx(0,0) && t1[0][0]==cplx(0,0))
                             {
                              for(j=0;j<n;j++)
                                  {
                                   a=t1[j][0];
                                   t1[j][0]=t1[j][i];
                                   t1[j][i]=a;
                                 }
                              a=t1[0][0];
                              s=cplx(-1,0);
                             }

                            if (t1[0][0]==cplx(0,0))
                                {
                                  a1=cplx(0,0);
				  delete [] t2;delete [] t1;return a1;
                                }
                       
                    }
                  
                    
                     for (i=1;i<n;i++)
                    t2[i]=-t1[i][0]/t1[0][0];

                    for (i=1;i<n;i++)
                    for (j=0;j<n;j++)
                     t1[i][j]=t1[i][j]+t2[i]*t1[0][j];
                    

                    

                    for (i=0;i<n-1;i++)
                    {
                        for (j=0;j<n-1;j++)
                        {
                         t1[i][j]=t1[i+1][j+1];
                         
                        }
                        
                    }
                    a1=a1*t1[0][0]*s;
                    n=n-1;

                  
                    
                }
             
		delete [] t1;
		delete [] t2;
            return a1*a;
}






void complex_cofactor(Vec & v1, Vec & v2)
{
	
        int n=(int)sqrt((float)v1.len());
         
                
	cplx (*t2)[18]=new cplx[18][18];
                int i,j,i1,j1,m1,m;m=m1=0;
               
             
                Vec t1((n-1)*(n-1),0);
                Vec s1((n-1)*(n-1),0);
               for (i=0;i<n;i++)
                    for(j=0;j<n;j++)
                        {
                         for (i1=0;i1<n;i1++)
                            for(j1=0;j1<n;j1++)
                            {
                                  if(i1!=i && j1!=j)
                                {
                                 t1[m]=v1[m1];
                                 s1[m]=v2[m1];
                                   m++;
                                }
                            m1++;
                            }
                                m=m1=0;
				
                t2[i][j]=(cplx(-1L,0L)^(i+j))*complex_det(t1,s1);
			}
			m=0;
		
                    for(i=0;i<n;i++)
                    for (j=0;j<n;j++)
                    {
                     v1[m]=t2[i][j].get_real();
			v2[m]=t2[i][j].get_img();   
                    
                    m++;
		    }
		    delete [] t2;
}

/*
void complex_inv(Vec & v1, Vec & v2)
{



         unsigned   int i,m; m=0;
             cplx a,c1;
	                a=complex_det(v1,v2);

	v1=rotate(v1);
		v2=rotate(v2);                

       
                complex_cofactor(v1,v2);
  
                  for(i=0;i<v1.len();i++)
		{
			c1=cplx(v1[m],v2[m])/a;
			
			v1[m]=c1.get_real();
			v2[m]=c1.get_img();
			m++;
		}
	

  

}

*/
void complex_inv(Vec & v1,Vec & v2)
{
   int i;

    cplx c=complex_det(v1,v2);
    complex_cofactor(v1,v2);

    cplx t1[9];


  for (i=0;i<9;i++)
       t1[i]=cplx(v1[i],v2[i])/c;



     for (i=0;i<9;i++)
     {
        v1[i]=t1[i].get_real();
        v2[i]=t1[i].get_img();

     }

}















