// Class operation can be performed as:
//  +,-,point-multiply (%), cross-multiply(^),for three-D vectors,
// for square matrix +,-,* (also with n x 1), inverse, determinant
// et al.
#include <iostream>
using namespace std;
#include "vec.h"
#include "cplx.h"
#include <cmath>
void newton(Vec & v1,Vec & v2, cplx & z); //algorizm using the newton method
void complex_cofactor(Vec & v1, Vec & v2);//cofactors in complex form
cplx complex_det(Vec v1,Vec v2);
void complex_inv(Vec & v1,Vec & v2);
Vec m3(Vec & v1, const Vec & v2, const Vec & v3);
Vec inv (Vec v);
double mode(Vec & v);
void set_tensor(const  double &  val,const  int & n,Vec & v);
Vec axis(Vec & v,Vec & u);
Vec extra(const int & n1, const int & n2,Vec & v);
Vec rotate (Vec & v);
void replace(Vec & v, int n1, int n2, Vec & u);




void stroh( Vec Beam,Vec u,Vec b,Vec g,Vec & cp1,Vec & cp2,Vec & cp3,Vec & cp4)

{
	int i,j;
	j=0; 
    Vec L_real,L_img,M_real,M_img,H,d;
    Vec OX3=u;//to estblish dislocation axis system ox3=dislocation sense
    Vec OX1=Beam^u;//ox2=beam direction x ox3
    Vec OX2=OX3^OX1;//ox2=ox2 x ox3
    
    OX1=OX1*(1/mode(OX1));//normalization of axis transfermation
    OX2=OX2*(1/mode(OX2));//parameter
    OX3=OX3*(1/mode(OX3));

   Vec DC;
    DC=m3(OX1,OX2,OX3);//to establish axis transfermation matrix
    b=DC*b;		//burger vector in dislocation axis system

    Vec gd=DC*g;	//diffraction vector in dislocation axis system
    //cout<<"g="<<gd;
     Vec tensor(81,0); //create a 9 x 9 tensor 
   
   double c,r;

//enter c11, c12 and c44 into the tensor (4-index)   
   c=cp1[2]/cp1[2];
  set_tensor(c,44,tensor);
  set_tensor(c,55,tensor);
  set_tensor(c,66,tensor);

  c=cp1[0]/cp1[2];
    set_tensor(c,11,tensor);
    set_tensor(c,22,tensor);
    set_tensor(c,33,tensor);  

    c=cp1[1]/cp1[2];
    set_tensor(c,12,tensor);
    set_tensor(c,21,tensor);
    set_tensor(c,23,tensor);  
    set_tensor(c,32,tensor);
    set_tensor(c,13,tensor);
    set_tensor(c,31,tensor);
//	tensor.show_tensor();  //show the created 9x9 tensor 
    
    tensor=axis(DC,tensor); //perform tensor axis transfermation by
			    //Cijkl=DCip*DCjq*DCkr*DCls*Cpqrs straightfoward
			    
//	tensor.show_tensor();	show the tensor after the transfermation
    // determinant |a f e|
    //             |f b d|=abc+2def-add-bee-cff
    //             |e d c|
    
    
  Vec A=extra(1,1,tensor);// Cm1n1(9,0);
    Vec B=extra(1,2,tensor)+extra(2,1,tensor); // Cm1n2+Cm2n1
    Vec C=extra(2,2,tensor);//Cm2n2
    // A+Bx+Cx*x--> a0+a1x+a2x^2+a3x^3+a4x^4+a5x^5+a6x^6
    // The following calculations produce a0...a6
    
    Vec tmp,tmp1;
    tmp=Vec(A[0],B[0],C[0])/Vec(A[4],B[4],C[4])/Vec(A[8],B[8],C[8]);
    tmp1=Vec(A[5],B[5],C[5])/Vec(A[2],B[2],C[2])/Vec(A[1],B[1],C[1]);
    tmp1=tmp1*2;
    tmp=tmp+tmp1;
    tmp1=Vec(A[0],B[0],C[0])/Vec(A[5],B[5],C[5])/Vec(A[7],B[7],C[7]);
    tmp1=-tmp1;
    tmp=tmp+tmp1;
    tmp1=Vec(A[4],B[4],C[4])/Vec(A[2],B[2],C[2])/Vec(A[6],B[6],C[6]);
    tmp1=-tmp1;
    tmp=tmp+tmp1;
    tmp1=Vec(A[8],B[8],C[8])/Vec(A[1],B[1],C[1])/Vec(A[1],B[1],C[1]);
    tmp1=-tmp1;
    tmp=tmp+tmp1;
    tmp=tmp*(1/tmp[6]);
    M_real=tmp;	
    // End. tmp[0]...tm[6]=a0..a6
    Vec pr,pi,Pr,Pi;
    tmp1=Vec(7,0);
    cplx z(.1,1);
    
    newton(tmp,tmp1,z);
   pr[0]=z.get_real();
   pi[0]=abs(z.get_img());
    
    z=cplx(z.get_real(),-z.get_img());
    newton(tmp,tmp1,z);
  
  
    z=cplx(.5,.9);
    newton(tmp,tmp1,z);
     pr[1]=z.get_real();
   pi[1]=abs(z.get_img());
 
     z=cplx(z.get_real(),-z.get_img());
    newton(tmp,tmp1,z);
     
 
      z=cplx(-z.get_real(),z.get_img());
    newton(tmp,tmp1,z);
       pr[2]=z.get_real();
   pi[2]=abs(z.get_img());

	r=0;
	double q=0;

	c=-tensor(3,2,3,1)/tensor(3,2,3,2);
	r=sqrt(abs(tensor(3,2,3,2)*tensor(3,1,3,1)-tensor(3,2,3,1)*
	tensor(3,2,3,1)))/tensor(3,2,3,2);

	for (i=0;i<2;i++)
	{
		
 
		if (  (c-pr[i])*(c-pr[i])+(r-pi[i])*(r-pi[i])-		
			(c-pr[i+1])*(c-pr[i+1])-(r-pi[i+1])*(r-pi[i+1]) 
			<0)
		{
		q=pr[i];
		pr[i]=pr[i+1];
		pr[i+1]=q;
		q=pi[i];
		pi[i]=pi[i+1];		
		pi[i+1]=q;
		}
	}

   Pr=m3(pr,pr,pr);Pi=m3(pi,pi,pi);
	tmp1=Vec(9,0);
    Vec A_real,A_img;
            	
        A_real=Vec(9,0);A_img=Vec(9,0);

	
	d=Vec(9,0);

	for(i=0;i<3;i++)  
	{
	
	L_real=C*(pr[i]*pr[i])-C*(pi[i]*pi[i])+B*pr[i]+A;
    	L_img=B*pi[i]+C*(pi[i]*pr[i]*2);
    	tmp=L_real; tmp1=L_img;
        complex_cofactor(tmp,tmp1);
      
        replace(tmp,i*3,i*3+2,A_real);
        replace(tmp1,i*3,i*3+2,A_img);

		
	}
	

	A_real=rotate(A_real);
	A_img=rotate(A_img);


    B=extra(2,1,tensor);
    tmp=C*A_real;
    tmp1=C*A_img;
    tmp=tmp&Pr;
    tmp1=tmp1&Pi;    
    L_real=B*A_real+tmp-tmp1;

    tmp=C*A_real;
    tmp1=C*A_img;
    tmp=tmp&Pi;
    tmp1=tmp1&Pr;    
    L_img=B*A_img+tmp+tmp1;
    

    tmp=L_real;
    tmp1=L_img;
    tmp=rotate(tmp);
    tmp1=rotate(tmp1);
    complex_inv(tmp,tmp1);

    M_real=tmp;
    M_img=tmp1;

    B=-A_real*M_img-A_img*M_real;



 
    H=inv(B);//cofactor(rotate(B));
		
    d=H*b;


    tmp=gd*A_real;
    tmp1=gd*A_img;

    A=(tmp&pr)-(tmp1&pi);
    C=(tmp&pi)+(tmp1&pr);

    tmp=M_real*H;
    tmp1=M_img*H;
    A=m3(A,A,A);
    A=rotate(A);
    C=m3(C,C,C);C=rotate(C);

    Vec V_real,V_img;
    V_real=(A&tmp)-(C&tmp1);
    V_img=(A&tmp1)+(C&tmp);
   

	
    
    Pr=rotate(Pr);
    Pi=rotate(Pi);
    tmp=(V_real&Pr)+(V_img&Pi);

    cp1=V_real*b;
    cp2=tmp*b;
    cp3=pr;
    cp4=(pi&pi);


}
/*
void complex_cofactor(Vec & v1, Vec & v2)
{
    int i,j,i1,j1,m,m1,m2;
    m=0;
    cplx t1[9];
    for (i=0;i<9;i++)
    {
        t1[m]=cplx(v1[m],v2[m]);
        m++;
    }

    m=0;m1=0;m2=0;
    cplx t2[9],t3[4];
    for (i=0;i<3;i++)
        for(j=0;j<3;j++)
        {
              for (i1=0;i1<3;i1++)
                for (j1=0;j1<3;j1++)
                  {
                      if (i1!=i && j1!=j)
                     {
                         t3[m]=t1[m2];
                            m++;
                        }
                        m2++;
                  }
                m=0;
                 m2=0;   
                t2[m1]=t3[0]*t3[3]-t3[1]*t3[2];
                       
                if((i+j)!=int((i+j)/2)*2  )
                t2[m1]=-t2[m1];
                m1++;
        }
        m=0;
      for (i=0;i<9;i++)
    {
   
        v1[m]=t2[m].get_real();
        v2[m]=t2[m].get_img();
        m++;
    }   
        
        
                
}

cplx complex_det(Vec v1,Vec v2)
{
     int i ;
    cplx sum;
    cplx t1[9];
    for (i=0;i<9;i++)
    {
       t1[i]=cplx(v1[i],v2[i]);
        
    }
    sum=t1[0]*(t1[4]*t1[8]-t1[5]*t1[7])-t1[1]*
        (t1[3]*t1[8]-t1[5]*t1[6])+t1[2]*
        (t1[3]*t1[7]-t1[4]*t1[6]);
  
        return sum;
}

void complex_inv(Vec & v1,Vec & v2)
{
   int i;
    
    cplx c=complex_det(v1,v2);
    complex_cofactor(v1,v2);
    
    cplx t1[9];
    

  for (i=0;i<9;i++)
       t1[i]=cplcx(v1[i],v2[i])/c;
        

    
     for (i=0;i<9;i++)
     {
        v1[i]=t1[i].get_real();
        v2[i]=t1[i].get_img();
        
     }
    
}
*/




