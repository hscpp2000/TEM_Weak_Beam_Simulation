#include <iostream>
#include <cmath>
using namespace std;
#include "cplx.h"
#include "vec.h"

void comhes( int & n, Vec & Ar, Vec & Ai,int * imt)
{
    int i,j,m,la,mm1,kp1,mp1;
    double xr,xi, yr,yi;
  
 
    la=n-1;
    kp1=2;
    if (la<kp1){cout<<"matrix < 2"<<endl;exit(1);}

    for (m=kp1;m<=la;m++)
    {
        mm1=m-1;
        xr=0.0L;
        xi=0L;
        i=m;

           for(j=m;j<=n;j++)
           {
    if(  abs(Ar(j,mm1))+abs(Ai(j,mm1))  > abs(xr)+abs(xi)   )
           {
            xr=Ar(j,mm1);
            xi=Ai(j,mm1);
            i=j;
           }
           }
           
            imt[m]=i;
            if(i!=m)
               {
                for(j=mm1;j<=n;j++)
                {
                    yr=Ar(i,j);
                    Ar(i,j)=Ar(m,j);
                    Ar(m,j)=yr;
                    yi=Ai(i,j);
                    Ai(i,j)=Ai(m,j);
                    Ai(m,j)=yi;
                }

                for (j=1;j<=n;j++)
                {
                    yr=Ar(j,i);
                    Ar(j,i)=Ar(j,m);
                    Ar(j,m)=yr;
                    yi=Ai(j,i);
                    Ai(j,i)=Ai(j,m);
                    Ai(j,m)=yi;
                }
               }

                if (xr==0.L && xi==0L){cout<<"matrix=0";exit(1);} 
                
                    mp1=m+1;
                    for (i=mp1;i<=n;i++)
                    {
                        yr=Ar(i,mm1);
                        yi=Ai(i,mm1);
                        if(yr!=0L || yi!=0L)
                        {
                         Ar(i,mm1)=(cplx(yr,yi)/cplx(xr,xi)).get_real();
                         Ai(i,mm1)=(cplx(yr,yi)/cplx(xr,xi)).get_img();
                         yr=Ar(i,mm1);
                         yi=Ai(i,mm1);
                         for (j=m;j<=n;j++)
                         {
                           Ar(i,j)=Ar(i,j)-yr*Ar(m,j)+yi*Ai(m,j);
                           Ai(i,j)=Ai(i,j)-yr*Ai(m,j)-yi*Ar(m,j);
                         }
                         for(j=1;j<=n;j++)
                         {
                            Ar(j,m)=Ar(j,m)+yr*Ar(j,i)-yi*Ai(j,i);
                            Ai(j,m)=Ai(j,m)+yr*Ai(j,i)+yi*Ar(j,i);
                         }
                         
                        }
                    
		    }        
            
    }
}
