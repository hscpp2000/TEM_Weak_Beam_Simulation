#include <iostream>
#include <cmath>
using namespace std;
#include "cplx.h"
#include "vec.h"

void combak( int & n, Vec & Ar, Vec & Ai,Vec & Zr, Vec & Zi,int * imt)
{
    int i,j,m,la,mm,mp,kp1,mp1;
    double xr,xi;
    
    m=n;
 
    la=n-1;
    kp1=2;
    if (la<kp1){cout<<"matrix < 2"<<endl;exit(1);}

    for (mm=kp1;mm<=la;mm++)
    {
        mp=1+n-mm;
        mp1=mp+1;
       
           for(i=mp1;i<=n;i++)
           {
               xr=Ar(i,mp-1);
               xi=Ai(i,mp-1);
           if(xr==0 && xi==0) continue ;
               
               for (j=1;j<=m;j++)
               {
                   Zr(i,j)=Zr(i,j)+xr*Zr(mp,j)-xi*Zi(mp,j);
                   Zi(i,j)=Zi(i,j)+xr*Zi(mp,j)+xi*Zr(mp,j);
               }
           
           }
        
        i=imt[mp];
        if(i!=mp)
        {
        for (j=1;j<=m;j++)
        {
            xr=Zr(i,j);
            Zr(i,j)=Zr(mp,j);
            Zr(mp,j)=xr;
            xi=Zi(i,j);
            Zi(i,j)=Zi(mp,j);
            Zi(mp,j)=xi;
            
            
        }
        }
    }
}
