// This is an adaptive stepsize control program
// using Runge-Kutta method, surprisingly fast! and accurate!!!

#include <iostream>
using namespace std;
#include <cmath>
#include "vec.h"
#include "cplx.h"
#include "ing.h"


//void derivs(double z, double * y, double * y2,double * dydz,double * dydz2);
//void rkqs(double * y, double * y2,double * dydz, double * dydz2,
//int & nvar,double & z ,double & h,
//double & eps, double * yscal, double & hdid, double & hnext);
//void rkck(double * y,double * y2,double * dydz,
//double * dydz2,int & n,double & z,
//double & h, double * yout,double * yout2,double * yerr);

void ing()

{
    int nvar=nd;

    double z1,z2,eps,h1,hmin;

    eps=1e-4;h1=1e-2;hmin=1e-58;
    
    int max_step=2098;
    double tiny=1e-30;

    int i,nstp;
    double h,hdid,hnext,z,hfix;
    hfix=0;
    double y[nvar],y2[nvar],dydz[nvar],dydz2[nvar],yscal[nvar],yscal2[nvar];

    double ht=0.5*thick;
    z1=ht;z2=-ht;
    ht2=ht;
    if(ang==1)ht2=0;
    if(ang<0)ht2=-ht;
    
    
    
    z=z1;
    h=h1*(z2-z1)/abs(z2-z1);


    for(i=0;i<nvar;i++)
    {
        y[i]=br[i];
        y2[i]=bi[i];
    }
 
    for(nstp=0;nstp<max_step;nstp++)
    {
        derivs(z,y,y2,dydz,dydz2);

        for(i=0;i<nvar;i++)
        {
            yscal[i]=abs(y[i])+abs(h*dydz[i])+tiny;
            yscal2[i]=abs(y2[i])+abs(h*dydz2[i])+tiny;
            
        }
        if( (z+h-z2)*(z+h-z1)>0 )h=z2-z;
        rkqs(y,y2,dydz,dydz2,nvar,z,h,eps,yscal,yscal2,hdid,hnext);
        
       if ((z-z2)*(z2-z1)>=0.)
        {        
          for(i=0;i<nvar;i++)
          {
           br[i]=y[i];
           bi[i]=y2[i];
          }
//                 cout<<nstp<<"   ";
        } 
       if ((z-z2)*(z2-z1)>=0.)break;
        
        
        if( abs(hnext)<hmin )
        {cout<<" step size reached the limitation";exit(1);}
    
        h=hnext;

        

    }
    
    

}

void rkqs(double * y, double * y2,double * dydz,
double * dydz2,int & n, double & z, double & htry,
double & eps, double * yscal, double * yscal2,double & hdid, double & hnext)
{
    int i;
    int sw=1;
    double errmax,h,znew,yerr[n],yerr2[n],ytemp[n],ytemp2[n],
    safety,pgrow,pshrnk,errcon;
    double max2=0;
        safety=0.9;
        pgrow=-.2;
        pshrnk=-.25;
        errcon=1.89e-4;
        h=htry;

        while (sw==1)
        {
        rkck(y,y2,dydz,dydz2,n,z,h,ytemp,ytemp2,yerr,yerr2);
        errmax=0.;
            
        for (i=0;i<n;i++)
            {
//                if (abs(yerr[i]/yscal[i])>abs(yerr2[i]/yscal2[i]))
  //              max2=abs(yerr[i]/yscal[i]);
    //            else
      //          max2=abs(yerr2[i]/yscal2[i]);
		max2=sqrt(yerr[i]*yerr[2]+yerr2[i]*yerr2[i])/
			sqrt(yscal[i]*yscal[i]+yscal2[i]*yscal2[i]);
            if (errmax<=max2)
            errmax=max2;
            }

        errmax=errmax/eps;
//    cout<<errmax<<" "<<h<<" "<<z<<endl;
        if(errmax>1)
        {
            h=safety*h*exp(pshrnk*log(errmax));
            if(h<0.1*h)h=h*0.1;
            znew=z+h;
            if(znew==z){cout<<" stepsize underflow "<<h<<endl;exit(1);}
            
        }
        else break;
	}

	if (errmax>errcon)
	hnext=safety*h*exp(pgrow*log(errmax));
        else
        hnext=5*h;

        hdid=h;
        z=z+h;
        

        for(i=0;i<n;i++)
        y[i]=ytemp[i];

}

void rkck(double * y, double * y2,double * dydz,double * dydz2,
int & n, double & z,
double & h, double * yout, double * yout2,double * yerr,double * yerr2)
{
    double ak2[n],ak3[n],ak4[n],ak5[n],ak6[n];
    double bk2[n],bk3[n],bk4[n],bk5[n],bk6[n];
    double ytemp[n],ytemp2[n];
    double a2,a3,a4,a5,a6,b21,b31,b32,b41;
    double b42,b43,b51,b52,b53,b54,b61,b62,b63,b64;
    double b65,c1,c3,c4,c6,dc1,dc3,dc4,dc5,dc6;
    
    a2=0.2;a3=0.3;a4=0.6;a5=1.;a6=0.875;
    
    b21=.2;b31=3./40.;b32=9./40.;b41=.3;b42=-.9;b43=1.2;b51=-11./54.;
    b52=2.5;b53=-70./27.;b54=35./27.;b61=1631./55296.;b62=175./512.;
    b63=575./13824.;b64=44275./110592.;b65=253./4096.;
    
    c1=37./378.;c3=250./621.;c4=125./594.;c6=512./1771.;
    
    dc1=c1-2825./27648.;dc3=c3-18575./48384.;
    dc4=c4-13525./55296.;dc5=-277./14336.;dc6=c6-.25;
    
    int i;
    for(i=0;i<n;i++)
    {
        ytemp[i]=y[i]+b21*h*dydz[i];
        ytemp2[i]=y2[i]+b21*h*dydz2[i];
    }


    derivs(z+a2*h,ytemp,ytemp2,ak2,bk2);

    for(i=0;i<n;i++)
    {
        ytemp[i]=y[i]+h*(b31*dydz[i]+b32*ak2[i]);
       ytemp2[i]=y2[i]+h*(b31*dydz2[i]+b32*bk2[i]);        
    }
    
    derivs(z+a3*h,ytemp,ytemp2,ak3,bk3);

    for(i=0;i<n;i++)
    {
        ytemp[i]=y[i]+h*(b41*dydz[i]+b42*ak2[i]+b43*ak3[i]);
        ytemp2[i]=y2[i]+h*(b41*dydz2[i]+b42*bk2[i]+b43*bk3[i]);
    }        

    derivs(z+a4*h,ytemp,ytemp2,ak4,bk4);

    for(i=0;i<n;i++)
    {
        ytemp[i]=y[i]+h*(b51*dydz[i]+b52*ak2[i]+b53*ak3[i]+b54*ak4[i]);
        ytemp2[i]=y2[i]+h*(b51*dydz2[i]+b52*bk2[i]+b53*bk3[i]+b54*bk4[i]);
    }        

    derivs(z+a5*h,ytemp,ytemp2,ak5,bk5);

    for(i=0;i<n;i++)
    {
    ytemp[i]=y[i]+h*(b61*dydz[i]+b62*ak2[i]+b63*ak3[i]+b64*ak4[i]+b65*ak5[i]);
    ytemp2[i]=y2[i]+h*(b61*dydz2[i]+b62*bk2[i]+b63*bk3[i]+b64*bk4[i]+b65*bk5[i]);
    }    

    derivs(z+a6*h,ytemp,ytemp2,ak6,bk6);

    for (i=0;i<n;i++)
    {
    yout[i]=y[i]+h*(c1*dydz[i]+c3*ak3[i]+c4*ak4[i]+c6*ak6[i]);
    yout2[i]=y2[i]+h*(c1*dydz2[i]+c3*bk3[i]+c4*bk4[i]+c6*bk6[i]);    
    yerr[i]=h*(dc1*dydz[i]+dc3*ak3[i]+dc4*ak4[i]+dc5*ak5[i]+dc6*ak6[i]);
    yerr2[i]=h*(dc1*dydz2[i]+dc3*bk3[i]+dc4*bk4[i]+dc5*bk5[i]+dc6*bk6[i]);

    }
    

    
    

    



    
}

//void derivs(double z, double * y, double * y2,double * dydz, double * dydz2)

   	
void derivs(double  z, double * Br,double * Bi,double * fr,double * fi)
{
    
    int i1=0;
    double y;
    if (ang==0.)y=-z;
    else
  {
    if (0.5*thick-u0*tang>=0)
    y=-ang*(0.5*thick-u0*tang+z);
    else 
      y=-1./ang*(z+0.5*thick-u0*tang);
  }
    double x1=-x;
    Vec Gr(nd,0);
    Vec Gi(nd,0);
    Vec Rr(nd,0);
    Vec Ri(nd,0);
    Vec Beta(nd,0);
    
    Vec tr(nd*nd,0);Vec ti(nd*nd,0);



 
      


             for (i1=0;i1<nd;i1++)
             {

   
            Beta[i1]=drdz((cp1*gvec[i1]),(cp2*gvec[i1]),
               (cp3*gvec[i1]),(cp4*gvec[i1]),x1,y);
                 Gr[i1]=cos(Wr[i1]*z)*exp(-Wi[i1]*z);
                 Gi[i1]=sin(Wr[i1]*z)*exp(-Wi[i1]*z);
	
		Rr[i1]=cos(Wr[i1]*z)*exp(Wi[i1]*z);
		Ri[i1]=-sin(Wr[i1]*z)*exp(Wi[i1]*z);

           }
   /*     tr=( ((Rr|Zi)*(Beta|Zr)) | Gr )-( ((Ri|Zi)*(Beta|Zr)) | Gi );
        ti=( ((Rr|Zi)*(Beta|Zr)) | Gi )+( ((Ri|Zi)*(Beta|Zr)) | Gr );*/

    tr=(Zi|Beta)*Zr;
    ti=Ri|tr;
    tr=Rr|tr;
    Rr=Vec(nd*nd,0);
    Ri=Vec(nd*nd,0);
    Rr=(tr|Gr)-(ti|Gi);
    Ri=(tr|Gi)+(ti|Gr);


    Gr=Vec(Br,nd);
    Gi=Vec(Bi,nd);
    tr=Vec(nd,0);
    ti=Vec(nd,0);
    tr=Rr*Gr-Ri*Gi;
    ti=Rr*Gi+Ri*Gr;

    for (i1=0;i1<nd;i1++)
        {
            fr[i1]=ti[i1]*-2.*pi;
            fi[i1]=tr[i1]*2.*pi;
        }
  


}


double drdz(Vec v1, Vec v2,Vec v3,Vec v4,double & xx,double & yy)
{
    double c=0;
    int i;
    for (i=0;i<3;i++)
    c=c+(v1[i]*xx+v2[i]*yy)/( (xx+yy*v3[i])*(xx+yy*v3[i])
        +yy*yy*v4[i]);
    c=c/2./pi;
    return c;
}




 





