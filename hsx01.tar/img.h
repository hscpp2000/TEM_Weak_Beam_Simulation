#ifndef _IMG_H_
#define _IMG_H_
#include "vec.h"


Vec Wr,Wi,Zr,Zi,fp1,fp2,fp3;
double thick,u0,ang,tang,FNBM,bng,bFNBM,tFNBM;
double dc1,da,dc2,pt1,pt2,pt3,uu,dp1,w2,length0;
 double u1,ut,length,FB;
double dz,R1,R2,R3,R4,R5,c1,c2,c3,c4,s1,s2,s3,s4,s5;
 int nd,nf,np,stiff;
Vec cp1,cp2,cp3,cp4,cq1,cq2,cq3,cq4,cr1,cr2,cr3,cr4,cs1,cs2,cs3,cs4;
short int dcode[4];
Vec C3r,C3i,D3r,D3i;
Vec gvec,Ar,Ai;
double pi=3.1415926535897932384626433832795;
int row=256;	//256;
 double width=64;
     double dx;
int ncl=512;
void stroh( Vec Beam,Vec u,Vec b,Vec g,Vec & v1,Vec & v2,Vec & v3,Vec & v4);
void cg(int & n, Vec & v1, Vec & v2,Vec & v3, Vec & v4,Vec & v5, Vec & v6);
void complex_inv(Vec & v1,Vec & v2);
void ing(Vec& br, Vec& bi,double& x);
void ingfault(Vec& br, Vec& bi,double& x);
Vec g;
void rs(int & n,Vec & a,Vec & w,Vec & z);
//void Vec_Arr(Vec & v1, double * p1, int n);

double drdz(Vec v1,Vec v2, Vec v3, Vec v4,double & x,double & y);
Vec m2(Vec & v1, Vec & v2);
#endif
