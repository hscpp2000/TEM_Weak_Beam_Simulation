// main program for calculating transmission electron
//microgras based on dynamical scattering theory by Howie et al.
// and elastic theory by Stroh.
//
// In alogorisms the formulas are the forms in the book by
//Hirsch, Howie,.... and Weilan..
//Stress/strain field is based on Stroh's work and formulization by 
//A. Head et al (1973)


/*Techniqes :
A class called 'Vec' (meaning vector) was defined as a n-element arrray.
It can be a matrix or vector (3-d) or an array. operators are defined to
operate its function







*/


#include <iostream>
#include <cstring>
#include <fstream>
#include <stdlib.h>
using namespace std;
#include "vec.h"
#include "cplx.h"
#include <cmath>
#include "img.h"
#include <iomanip>
#include <omp.h>
//#include <tiffio.h>
double mode(Vec & v);
Vec rotate(Vec & v);
Vec get_col(int n1,Vec & v);
void exc_c(int n1, int n2, Vec & v);
void exc_r(int n1, int n2, Vec & v);
Vec m3(Vec & v1, const Vec & v2, const Vec & v3);
//Vec inv(Vec  v);

int main()

{
        int i;
        char par[40];	//title for inputs
	char fname[20];
         nd=0;
        thick=51.2;
	double thinnest;		// the thinnest thickness
	double thickest;		//the thickest thickness
	double fi1;
        Vec Beam(1,0,1); 			//beam direction
    	Vec u(1,-1,0); 			//dislocation direction
	Vec u2(1,1,0);                  //dislocation2 directio 
        Vec b1,b2,b3,b4;		//Burgers vectors
	double p2=pi*.5;
        //Vec Ar,Ai;     //complex matrix of potentials
	
        g=Vec(2,0,-2);			//diffraction vector
 	dcode[0]=dcode[1]=dcode[2]=dcode[3]=0;// 1/0 with/without dislocations

	Vec foil(1,1,2);		//foil normal
        double E;			// electron energy
	cin>>par>>fname;                //image file name
	cin>>par>>Ar;			// elatic constants
        cin>>par>>E;
        E=12.26/sqrt(E*1000.)*.1/sqrt(1+0.9788*0.001*E);
        
        gvec=Vec(4,0);       
	cin>>par>>Beam;//Beam direction
	cin>>par>>u;//dislocation line direction
	cin>>par>>gvec;b1=Vec(gvec[0],gvec[1],gvec[2]);b1=b1*(1./gvec[3]);//Burgers vector 1
	cin>>par>>gvec;b2=Vec(gvec[0],gvec[1],gvec[2]);b2=b2*(1./gvec[3]);//Burgers vector 2
	cin>>par>>gvec;b3=Vec(gvec[0],gvec[1],gvec[2]);b3=b3*(1./gvec[3]);//Burgers vector 3
	cin>>par>>gvec;b4=Vec(gvec[0],gvec[1],gvec[2]);b4=b4*(1./gvec[3]);//Burgers vector 4
	cin>>par>>g;dc1=g[0];da=g[1];dc2=g[2];//fault spacings

	cin>>par>>g;//reflection vector

	cp1=cp2=cp3=cp4=cq1=cq2=cq3=cq4=cr1=cr2=cr3=cr4=cs1=cs2=cs3=cs4=Vec(3,0.0000000l);


	if((Beam%u)/mode(Beam)/mode(u)==1.){cout<<" Beam is paraelle to dislocation line!"<<endl;exit(1);}
	if(Beam%g!=0.){cout<<" beam must be perpendicular to g"<<endl;exit(1);}
	if(Beam%u<0){cout<<"reverse dislocation line 180!"<<endl;exit(1);}




	if(mode(b1)!=0.)
	{
	  dcode[0]=1;
		cp1=Ar;
	  stroh(Beam,u,b1,g,cp1,cp2,cp3,cp4);
	}

	if(mode(b2)!=0)
	{
	  dcode[1]=1;
		cq1=Ar;
	  stroh(Beam,u,b2,g,cq1,cq2,cq3,cq4);
	}

	if(mode(b3)!=0)
	{
	  dcode[2]=1;
		cr1=Ar;
	  stroh(Beam,u,b3,g,cr1,cr2,cr3,cr4);
	}

	if(mode(b4)!=0)
	{
	  dcode[3]=1;
		cs1=Ar;
	  stroh(Beam,u,b4,g,cs1,cs2,cs3,cs4);
	}


	cin>>par>>foil;                 //foil normal



	Vec OX3=u;                    //defect axis x3
	Vec OX1=Beam^u;               //defect axis x1
	Vec OX2=OX3^OX1;              //defect axis x2

	OX1=OX1*(1/mode(OX1));    //normalization of defect axis
    OX2=OX2*(1/mode(OX2));
    OX3=OX3*(1/mode(OX3));


    Vec DC(9,0);                 //axis transform matrix
    DC=m3(OX1,OX2,OX3);         // constructing defect transform matrix



    OX1=-(Beam^u);OX2=-Beam;OX3=OX1^OX2; //image axis
    OX1=OX1*(1/mode(OX1));
    OX2=OX2*(1/mode(OX2));
    OX3=OX3*(1/mode(OX3));
    Vec DCX(9,0);
    DCX=m3(OX1,OX2,OX3);

    Vec FN,FNX,BM;
    FN=DC*foil;
        FN=FN*(1./mode(FN));
    FNX=DCX*foil;
    FNX=FNX*(1./mode(FNX));
    BM=DC*Beam;
    BM=BM*(1./mode(BM));
	


    gvec=Vec(5,0);
    Ai=g;     
    cin>>par>>gvec;Ar=Vec(gvec[0],gvec[1],gvec[2]);Ar=Ar*(gvec[3]/gvec[4]);

    R1=(g%Ar)*2*pi;if(fabs(cos(R1))==1)R1=0;
    cin>>par>>gvec;Ar=Vec(gvec[0],gvec[1],gvec[2]);Ar=Ar*(gvec[3]/gvec[4]);
    R2=(g%Ar)*(2*pi);if(fabs(cos(R2))==1)R2=0;
    
    cin>>par>>gvec;Ar=Vec(gvec[0],gvec[1],gvec[2]);Ar=Ar*(gvec[3]/gvec[4]);

    
    R3=(g%Ar)*(2*pi);
    if(fabs(cos(R3))==1)R3=0;

    cin>>par>>gvec;Ar=Vec(gvec[0],gvec[1],gvec[2]);Ar=Ar*(gvec[3]/gvec[4]);
    R4=(g%Ar)*(2*pi);if(fabs(cos(R4))==1)R4=0;
    cin>>par>>gvec;Ar=Vec(gvec[0],gvec[1],gvec[2]);Ar=Ar*(gvec[3]/gvec[4]);
    R5=(g%Ar)*(2*pi);if(fabs(cos(R5))==1)R5=0;
    
   
    cin>>par>>fp1;// fault 1 normal
    cin>>par>>fp2;// fault 2 normal
    cin>>par>>fp3;// fault 3 normal


	double zp1,zp2,zp3;
	fp1=DC*fp1;fp2=DC*fp2;fp3=DC*fp3;fp1=fp1*(1./mode(fp1));        
	fp2=fp2*(1./mode(fp2));        fp3=fp3*(1./mode(fp3));        
       	

	FB=cos(0.5*pi-acos(FN[0]));
	zp1=cos(0.5*pi-acos(fp1[0]));
	zp2=cos(0.5*pi-acos(fp2[0]));
	zp3=cos(0.5*pi-acos(fp3[0]));

	//zp1=(zp1*FB-fp1[0]*FN[0]);
	//zp2=(zp2*FB-fp2[0]*FN[0]);
	//zp3=(zp3*FB-fp3[0]*FN[0]);

//	double xp1,xp2,xp3;

	//xp1=cos(0.5*pi-acos(zp1));
	//xp2=cos(0.5*pi-acos(zp2));
	//xp3=cos(0.5*pi-acos(zp3));

	


	pt1=0.5*da*fp2[0]+dc1*fp1[0];
	pt2=0.5*da*fp2[0];
	pt3=0.5*da*fp2[0]+dc2*fp3[0];



	dc1=fabs(dc1*zp1);
	da=fabs(da*zp2);
	dc2=fabs(dc2*zp3);

	tang=bng*pt1;

	


	
	cin>>par>>nd;  //beam number
  
	gvec=Vec(nd,0);    
	cin>>par>>gvec;//  sysmatic beams

    Wr=Vec(nd-1,0); Wi=Vec(nd,0); //eigenvalues    
    Zr=Vec(nd-1,0); Zi=Vec(nd,0);     // eigen vectors
    double lau,lpa;
   cin>>par>>lau;//Lau centre
    cin>>par>>lpa;//lattice parameter
        for(i=0;i<nd;i++)
    Wi[i]=gvec[i]*mode(g)*mode(g)*(lau-gvec[i])*E*.5/lpa/lpa;
	
    short int nb;
    cin>>par>>nb;// beam forming image
    cin>>par>>Wr;Wr=Wr*2;//extinction distances
     cin>>par>>Zr;Zr=Zr*2;//extinction distance prime


      cin>>par>>thinnest;Zi=Vec(nd,thinnest);// normal fabsorption
	cin>>par>>thinnest;
	cin>>par>>thickest;

	double mag=1;
	cin>>par>>mag;if(mag<=0)mag=1;
	//cin>>par>>dz;
	double wra=0;
	//	cin>>par>>stiff;wra=tan(stiff*pi/180);
        Ar=m2(Wr,Wi);
      Ai=m2(Zr,Zi);

 
    if (gvec[0]!=0)
    {
        for (i=0;i<nd;i++)
    if(gvec[i]==0)
    { 
   exc_r(1,i+1,Ar);exc_c(1,i+1,Ar);
     exc_r(1,i+1,Ai);exc_c(1,i+1,Ai);
     E=gvec[0];gvec[0]=0;gvec[i]=E;
    }
    }
    

    for(i=0;i<nd;i++)
       if(nb==int(gvec[i])){nb=i;break;}
    
	Vec atmp=Ar;

	//    (Ar*inv(Ar)).show();exit(1);
    Wr=Vec(nd,0); Wi=Vec(nd,0);Zr=Vec(nd*nd,0);Zi=Vec(nd*nd,0);

   rs(nd,atmp,Wr,Zr);
	
   //cg(nd, Ar, Ai,Wr, Wi,Zr, Zi); //finding eigenvalues/vectors in complex seeming not working well
    Zi=((rotate(Zr))*Ai*Zr);
      for(i=1;i<=nd;i++)
      Wi[i-1]=Zi(i,i);
    Zi=rotate(Zr);




    int i1=1;

       
	ang=BM[1];
	
	bng=cos(p2-acos(ang));//sqrt(1-ang*ang);
	
	
	//FNBM=FN%BM;
	FNBM=cos(pi-acos(FNX[1]));
	//FNBM=FNBM*1/mode(FN)/mode(BM);
	bFNBM=cos(p2-acos(FNBM));//sqrt(1-FNBM*FNBM);

	 if(ang!=0) tang=sqrt(1.-ang*ang)/ang;
	 tFNBM=bFNBM/FNBM;	
	
    
        int num_threads=1;  //setup parall computing
	cin>>par>>num_threads;	
	if(num_threads==0)num_threads=1;
	omp_set_num_threads(num_threads);
	int i2=num_threads;
	
	ofstream fout(fname);
	double back=1.;



	if(ang==0) {cout<<" the dislocation is pararell to the beam";exit(1);}
	if (ang==1) length0=thickest*2;//(thickest)*BM[1]/FN[2]*FNBM;



	ut=0.5*(thickest-thinnest);



	if(FN[2]==0)FN[2]=.001;


	if(ang!=1 && FN[2]!=0){
	    length0=((thinnest)/(FN[2]));
	    if(length0<0) {cout<<"reverse foil normal";exit(1);}
	    	u1=ut/(length0*sin(acos(FN[2])));


		
	}
	if(ang==1){
	    
	    u1=ut/(length0);
	}
	double edge=0;   
        int j=0;


	double us=0;
	
	s2=sin(p2+acos(FNBM));c2=sin(p2-asin(s2));//sqrt(1-FNBM*FNBM);

	s1=sin(atan(u1));
	c1=sqrt(1-s1*s1);
	
	s3=sin(pi-asin(s1)-asin(s2));//s1*c2+s2*c1;
	c3=cos(p2-acos(s3));//sqrt(1-s3*s3);
	c4=BM[2]; s4=cos(p2-acos(c4));//sqrt(1-c4*c4);
	s5=s2*c4+s4*c2;
	s5=sin(p2+acos(FN[2]));

	

//	length=(length0-0.5*c2/s2*(thinnest+thickest))*FNBM;
	if(ang!=1)length=length0*ang+tang;
	else length=length0;
	
	edge=(length-length/mag)*.5;

	length=length/mag;
	

	width=0.5*length;

	row=int((width/length)*ncl);
	dx=width/double(row);
	w2=width*.5;	

	Vec rint,rint2,rint3;
	rint=Vec(ncl*row*4,0);
	rint2=Vec(ncl*row*4,0);
	rint3=Vec(ncl*row*4,0);

	double fmax=0;
	Vec br,bi,br2,bi2,sumr,sumr2,br3,bi3,sumr3;
	int i8=0;
	double x=0;
	nf=-1;	
	
	Vec ffmax=Vec(i2,0);
	fi1=1000;
	

	
	
	u0=0;
	uu=length/double(ncl);
	//	if(mag>1){edge=0;j=0;length0=length;}
	//	if (thinnest==thickest)	i1=int(length0/uu);
	//else 	i1=int(length0/uu);
	i1=int(length/uu);


	double x2;




	







		 cout<<" "<<endl;
	 cout<<" TEM image simulation of dislocation contrast "<<endl;
		 cout<<"using dynamical and elasticity anisotropy models"<<endl;
	cout<<" 2000.12  hscp2000@yahoo.com"<<endl;
	cout<<" Using C++ compilers with openMP "<<endl;
	cout<<" Output image in text image format read by IMAGEJ"<<endl;
	cout<<endl;
	cout<<endl;

	cout<<" Picture Height:"<<length<<" nm"<<endl;
	cout<<" Picture Width:"<<width<<" nm"<<" ("<<width/row<<" nm/pixel)"<<endl;
	cout<<" (H "<< i1<<" x W "<<row<<")"<<endl;
	
	int nstep=0;
		i1=0;
		//	if(stiff==1)
		    cout<<"Using a stiif integrator for HW equations"<<endl; 
		    //else 
		    //cout<<"Using Non stiff integrator for HW equations"<<endl;
	
		ut=0;
		int nn=0;
		c1=wra;
		cout<<endl;
		cout<<"foil tilting angle:"<<acos(FNBM)*180/pi<<endl;
		cout<<"beam with dislocation line:"<<acos(BM[2])*180/pi<<endl;
		cout<<"apparent thickness between "<<s1/s3*(thinnest*tFNBM)+thinnest/FNBM<<" and "<<s1/s3*(length/FNBM*2+thinnest*tFNBM)+thinnest/FNBM<<" nm "<<endl;
		cout<<"apparent fault widths (nm): "<<dc1<<", "<<da<<", "<<dc2<<endl;
		 

		double p100,p101,p102,p103,p104;
		p100=s1/s3;
		p101=2/FNBM;
		p102=thinnest*tFNBM;
		p103=thinnest/FNBM;
		p104=1/cos(p2-acos(FNX[0]));



		
		while(u0<length+edge)
    {
      

	u0=uu*double(j)+edge;
	

	thick=(s1/s3*(u0/FNBM*2+thinnest*tFNBM)+thinnest/FNBM)/cos(p2-acos(FNX[0]));
	c3=thinnest*.5/FNBM+s1/s3*(u0/FNBM+thinnest*tFNBM);

	c2=s1/s3*(tFNBM*thinnest+u0/FNBM)+s5/s4*(length-u0)/FNBM;
	
	c4=(p100*(u0*p101+p102)+p103)*p104;
	nstep=nstep+1;

	us=nstep;
	us=us/(double)(ncl+1)*100.;
	nn=nn+1;
	if (nn==5)
	  {cout<<setprecision(2)<<us<<" %"<<endl;nn=0;}
	//calculation background
	//ingfault(br3,bi3,fi1);
	//sumr3=(br3&br3)+(bi3&bi3);
	//ut=br3[0];
        ing(br,bi,fi1);
	br=(br&br)+(bi&bi);
        back=br[0]; 





    for(i=0;i<row;i+=i2)
    {


#pragma omp parallel for private(br,bi,br2,bi2,sumr,x) shared(i1,back,dx,w2,nb,sumr3,u0) 
      for (i8=0;i8<i2;i8++)
    { 


        x=(double)(i+i8)*dx-w2;
	// x2=(double)(i+i8)*dx-w2;
	//c4=(p100*((-x*wra+u0)*p101+p102)+p103)*p104;
		//c4=(s1/s3*((-x*wra+u0)/FNBM*2+thinnest*tFNBM)+thinnest/FNBM)/cos(p2-acos(FNX[0]));	
	//su0=(double)(i+i8)*dx;
	ing(br,bi,x);
//	ingfault(br2,bi2,x2);
//	ingfault(br3,bi3,fi1);


	sumr=(br&br)+(bi&bi);
	//sumr2=(br2&br2)+(bi2&bi2);
	//sumr3=(br3&br3)+(bi3&bi3);

	
	rint[i1+i8]=(sumr[nb])/back;
	
	//if(nb==0)ut=fabs(sumr2[0]-1)/back;
	//if(nb==0 && sumr2[0]>sumr3[nb])ut=sumr3[0]/sumr2[0];
	//rint2[i1+i8]=fabs(sumr2[nb]/back);
	
    }
	
		i1+=i2;   
            
 

    }
	
    j++;
	
   }
		//  for(i8=0;i8<i2;i8++)
		//if(fmax<ffmax[i8])fmax=ffmax[i8];
 
	int nl=j;
	back=0;
	i1=255;
	//fout<<"P5"<<endl;
	//fout<<"#simulation image"<<endl;
	//fout<<row<<" "<<height<<endl;
	//fout<<i1<<endl;
//		unsigned char aint='a';
	i1=0;
	//	ofstream fout(fname);
	for (j=0;j<nl;j++)
	{
		for(i=0;i<row;i++)
	  {
		//i2=int(rint[i1]/fmax*(255));//fmax*(65535))
	    //aint=i2;
		i1++;
		
		fout<<rint[i1]+rint2[i1]<<" ";//aint;

//		fout<<rint2[i1]<<" ";//aint;
		//fout<<(unsigned char) i2;

	  }
		fout<<'\n';
	}

fout.close();

 cout<<"END!";
 return 0;
}











