#ifndef _IMG_H_
#define _IMG_H_
#include "vec.h"


extern Vec Wr,Wi,Zr,Zi,D3r,D3i,C3r,C3i,fp1,fp2,fp3,Ar,Ai;
extern  double FNBM,ang,thick,u0,tang,u1,dc1,da,dc2,pt1,s1,s2,s3,s4,s5,length0;
extern  double  pt2,pt3,FB,length,bng,bFNBM,uu,ut,dp1,w2,c1,c2,c3,c4,tFNBM;
extern  int nd,nf,np,stiff;
extern short int dcode[];
extern  Vec cp1,cp2,cp3,cp4,cq1,cq2,cq3,cq4,cr1,cr2,cr3,cr4,cs1,cs2,cs3,cs4;
extern Vec gvec,g;
extern double R1,R2,R3,R4,R5;
extern double dx,ut,dz;
const double pi=3.1415926535897932384626433832795;
//int nstep=128;
//void derivs(double z, Vec v1, Vec v2, Vec & v3,Vec & v4);
//double drdz(Vec v1,Vec v2, Vec v3, Vec v4,double & x,double & y);


 



#endif

