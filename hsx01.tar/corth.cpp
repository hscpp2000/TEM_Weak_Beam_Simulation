#include <iostream>
#include <iostream>
#include <cmath>

#include <algorithm>
#include <stdio.h>
#include <stdlib.h>

using namespace std;
#include "cplx.h"
#include "vec.h"

double pythag (double a, double b);

void corth(int & n, Vec & Ar, Vec & Ai, double * ortr, double * orti)
{
    int i,j,m,ii,jj,la,mp,kp1;
    double f,g,h,fi,fr,scale;

 
    la=n-1;
    kp1=2;
    if (la<kp1){cout<<"matrix < 2"<<endl;exit(1);}

    for (m=kp1;m<=la;m++)
    {
           h=0.0;
           ortr[m]=0;
           orti[m]=0;
           scale=0;

           for(i=m;i<=n;i++)
           scale=scale+abs(Ar(i,m-1))+abs(Ai(i,m-1));
           
           if(scale==0) continue;
           mp=m+n;
           for(ii=m;ii<=n;ii++)
           {
                i=mp-ii;
                ortr[i]=Ar(i,m-1)/scale;
                orti[i]=Ai(i,m-1)/scale;
                h=h+ortr[i]*ortr[i]+orti[i]*orti[i];
           }
    
           g=sqrt(h);
           f=pythag(ortr[m],orti[m]);

           if(f!=0)
           {
            h=h+f*g;
            g=g/f;
            ortr[m]=(1+g)*ortr[m];
            orti[m]=(1+g)*orti[m];
           }
           else
           {
            ortr[m]=g;
            Ar(m,m-1)=scale;
           }
    
           for(j=m;j<=n;j++)
           {
            fr=0;
            fi=0;
                for(ii=m;ii<=n;ii++)
                {
                    i=mp-ii;
                    fr=fr+ortr[i]*Ar(i,j)+orti[i]*Ai(i,j);
                    fi=fi+ortr[i]*Ai(i,j)-orti[i]*Ar(i,j);
                }
     
                fr=fr/h;
                fi=fi/h;

                for(i=m;i<=n;i++)
                {
                    Ar(i,j)=Ar(i,j)-fr*ortr[i]+fi*orti[i];
                    Ai(i,j)=Ai(i,j)-fr*orti[i]-fi*ortr[i];
                }
                
           }
 
           for(i=1;i<=n;i++)
	      {
                fr=0;
                fi=0;
                for(jj=m;jj<=n;jj++)
                {
                    j=mp-jj;
                    fr=fr+ortr[j]*Ar(i,j)-orti[j]*Ai(i,j);
                    fi=fi+ortr[j]*Ai(i,j)+orti[j]*Ar(i,j);
                    
                }

                fr=fr/h;
                fi=fi/h;

                for(j=m;j<=n;j++)
                {
                    Ar(i,j)=Ar(i,j)-fr*ortr[j]-fi*orti[j];
                    Ai(i,j)=Ai(i,j)+fr*orti[j]-fi*ortr[j];
                }
           }

           ortr[m]=scale*ortr[m];
           orti[m]=scale*orti[m];
           Ar(m,m-1)=-g*Ar(m,m-1);
           Ai(m,m-1)=-g*Ai(m,m-1);
        
       
    }
}



