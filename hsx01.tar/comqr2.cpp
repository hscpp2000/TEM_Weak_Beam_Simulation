#include <iostream>
#include <cmath>

#include <algorithm>
#include <stdio.h>
#include <stdlib.h>

using namespace std;
#include "cplx.h"
#include "vec.h"

double pythag (double a, double b);
cplx csqrt(double a, double b);

void comqr2( int & n, Vec & Hr, Vec & Hi,Vec & Zr,
Vec & Zi,Vec & Wr, Vec & Wi,double * ortr, double * orti)
{
    int i,j,k,l,m,en,ii,jj,ll,nn,ip1,itn,its,lp1,enm1,iend;
    i=j=k=l=m=en=ii=jj=ll=nn=ip1=itn=its=lp1=enm1=iend=0;
    double si,sr,ti,tr,xi,xr,yi,yr,zzi,zzr,norm,tst1,tst2;
    cplx ct;
    double t1,t2;
    int sw=1;
    Zr=Zi=Vec (n*n,0);
   
    for(i=1;i<=n;i++)
        Zr(i,i)=1;

    iend=n-2;
 
    if(iend>0)
    {
        
        for(ii=1;ii<=iend;ii++)
        {
            i=n-ii;
            if(ortr[i]==0 && orti[i]==0) continue;
            if(Hr(i,i-1)==0 && Hi(i,i-1)==0) continue;
            norm=Hr(i,i-1)*ortr[i]+Hi(i,i-1)*orti[i];
            ip1=i+1;
            
            for(k=ip1;k<=n;k++)
            {
                ortr[k]=Hr(k,i-1);
                orti[k]=Hi(k,i-1);
                
            }
            
            for (j=i;j<=n;j++)
            {
                sr=0;si=0;
            
           
                for(k=i;k<=n;k++)
                {
                sr=sr+ortr[k]*Zr(k,j)+orti[k]*Zi(k,j);
                si=si+ortr[k]*Zi(k,j)-orti[k]*Zr(k,j);
                }
            
            sr=sr/norm;
            si=si/norm;
      
                for(k=i;k<=n;k++)
                {
                Zr(k,j)=Zr(k,j)+sr*ortr[k]-si*orti[k];
                Zi(k,j)=Zi(k,j)+sr*orti[k]+si*ortr[k];
                }
            }
            
            
        }
    }
  

    


        l=2;
        for(i=l;i<=n;i++)
        {
            if(i+1<n) 
            ll=i+1;
            else
            ll=n;
            if(Hi(i,i-1)==0) continue;
            norm=pythag(Hr(i,i-1),Hi(i,i-1));
            yr = Hr(i,i-1)/norm;
            yi = Hi(i,i-1)/norm;
            Hr(i,i-1) = norm;
            Hi(i,i-1) = 0.;
            for (j=i;j<=n;j++)
            {
              si=yr*Hi(i,j)-yi*Hr(i,j);
              Hr(i,j)=yr*Hr(i,j)+yi*Hi(i,j);
              Hi(i,j)=si;
            }

            for(j=1;j<=ll;j++)
            {
              si=yr*Hi(j,i)+yi*Hr(j,i);
              Hr(j,i)=yr*Hr(j,i)-yi*Hi(j,i);
              Hi(j,i)=si;  
            }

            for(j=1;j<=n;j++)
            {
                si=yr*Zi(j,i)+yi*Zr(j,i);
                Zr(j,i) = yr * Zr(j,i) - yi * Zi(j,i);
                Zi(j,i) = si;
            }
        }
        
    
    
          en = n;
          tr = 0.0;
          ti = 0.0;
          itn = 300*n;

    while(en>=1)
    {
        its=0;
        enm1=en-1;
    while(sw==1)
     {
        for(ll=1;ll<=en;ll++)
        {
            l=en+1-ll;
            if(l==1)break;
            tst1=abs(Hr(l-1,l-1))+abs(Hi(l-1,l-1))+
            abs(Hr(l,l))+abs(Hi(l,l));
            tst2=tst1+abs(Hr(l,l-1));
            if(tst2==tst1) break;
        }

     if(l==en)break;
     
        if(itn==0){cout<<"failed in getting eigens";exit(1);}
        if(its!=10 && its!=20)
        {
            sr=Hr(en,en);
            si=Hi(en,en);
            xr=Hr(enm1,en)*Hr(en,enm1);
            xi=Hi(enm1,en)*Hr(en,enm1);
            if(xr!=0 || xi!=0)
            {
                yr=(Hr(enm1,enm1)-sr)/2;
                yi=(Hi(enm1,enm1)-si)/2.;
            t1=yr*yr-yi*yi+xr;t2=2.0*yr*yi+xi;
        zzr=csqrt(t1,t2).get_real();
        zzi=csqrt(t1,t2).get_img();
            if(yr*zzr+yi*zzi<0)
            {
                zzr=-zzr;
                zzi=-zzi;
            }
            
            
            ct=cplx(xr,xi)/cplx(yr+zzr,yi+zzi);
            xr=ct.get_real();
            xi=ct.get_img();
            sr=sr-xr;
            si=si-xi;
            
           }

        }
        else
        {
            sr=abs(Hr(en,enm1))+abs(Hr(enm1,en-2));
            si=0;

        }
 
        for (i=1;i<=en;i++)
        {
            Hr(i,i)=Hr(i,i)-sr;
            Hi(i,i)=Hi(i,i)-si;
	}

	tr=tr+sr;
	ti=ti+si;
	its=its+1;
	itn=itn-1;
	lp1=l+1;
	for( i = lp1;i<= en;i++)
	{
         sr = Hr(i,i-1);
         Hr(i,i-1) = 0.;
        norm = pythag(pythag(Hr(i-1,i-1),Hi(i-1,i-1)),sr);
         xr = Hr(i-1,i-1) / norm;
         Wr[i-1] = xr;
         xi = Hi(i-1,i-1) / norm;
         Wi[i-1] = xi;
         Hr(i-1,i-1) = norm;
         Hi(i-1,i-1) = 0.0;
         Hi(i,i-1) = sr / norm;

         for( j = i;j<= n;j++)
           {
            yr = Hr(i-1,j);
            yi = Hi(i-1,j);
            zzr = Hr(i,j);
            zzi = Hi(i,j);
            Hr(i-1,j) = xr * yr + xi * yi + Hi(i,i-1) * zzr;
            Hi(i-1,j) = xr * yi - xi * yr + Hi(i,i-1) * zzi;
            Hr(i,j) = xr * zzr - xi * zzi - Hi(i,i-1) * yr;
            Hi(i,j) = xr * zzi + xi * zzr - Hi(i,i-1) * yi;
             }

        }

        si=Hi(en,en);
  
        if(si!=0)
        {
           norm = pythag(Hr(en,en),si);
            sr = Hr(en,en) / norm;
            si = si / norm;
            Hr(en,en) = norm;
            Hi(en,en) = 0.0;
       
        if (en!=n)
            {
                ip1 = en + 1;
       
                for( j = ip1;j<= n;j++)
                {
                    yr = Hr(en,j);
                    yi = Hi(en,j);
                    Hr(en,j) = sr * yr + si * yi;
                    Hi(en,j) = sr * yi - si * yr;
                }
            }

        }


          for(j = lp1; j<=en;j++)
          {
            xr = Wr[j-1];
            xi = Wi[j-1];
   
              for( i = 1;i<=j;i++)
                {
                yr = Hr(i,j-1);
                yi = 0.0;
                zzr = Hr(i,j);
                zzi = Hi(i,j);
                    if (i != j)
                    {
                        yi = Hi(i,j-1);
                        Hi(i,j-1) = xr * yi + xi * yr + Hi(j,j-1) * zzi;
                     }
                Hr(i,j-1) = xr * yr - xi * yi + Hi(j,j-1) * zzr;
                Hr(i,j) = xr * zzr + xi * zzi - Hi(j,j-1) * yr;
                    Hi(i,j) = xr * zzi - xi * zzr - Hi(j,j-1) * yi;
   
                }
         
            for( i = 1;i<=n;i++)
                {
                    yr = Zr(i,j-1);
                    yi = Zi(i,j-1);
                    zzr = Zr(i,j);
                    zzi = Zi(i,j);
                    Zr(i,j-1) = xr * yr - xi * yi + Hi(j,j-1) * zzr;
                    Zi(i,j-1) = xr * yi + xi * yr + Hi(j,j-1) * zzi;
                    Zr(i,j) = xr * zzr + xi * zzi - Hi(j,j-1) * yr;
                    Zi(i,j) = xr * zzi - xi * zzr - Hi(j,j-1) * yi;
     
                  }

            }


            if (si==0) continue;
            for (i=1;i<=en;i++)
            {
                yr=Hr(i,en);
                yi=Hi(i,en);
                Hr(i,en)=sr*yr-si*yi;
                Hi(i,en)=sr*yi+si*yr;
            }

            for(i=1;i<=n;i++)
            {
                yr=Zr(i,en);
                yi=Zi(i,en);
                Zr(i,en)=sr*yr-si*yi;
                Zi(i,en)=sr*yi+si*yr;
            }


        }   

        Hr(en,en)=Hr(en,en)+tr;
        Wr[en]=Hr(en,en);
        Hi(en,en)=Hi(en,en)+ti;
        Wi[en]=Hi(en,en);
        en=enm1;

    }

    norm=0;
    for (i=1;i<=n;i++)
    for(j=i;j<=n;j++)
    {
        tr=abs(Hr(i,j))+abs(Hi(i,j));
        if(tr>norm)norm=tr;

    }

    if(n!=1 && norm!=0)
{
        for(nn=2;nn<=n;nn++)
  {
            en=n+2-nn;
            xr=Wr[en];
            xi=Wi[en];
            Hr(en,en)=1;
            Hi(en,en)=0;
            enm1=en-1;

            for(ii=1;ii<=enm1;ii++)
            {
                i=en-ii;
                zzr=0;
                zzi=0;
                ip1=i+1;

                for(j=ip1;j<=en;j++)
                {
                    zzr=zzr+Hr(i,j)*Hr(j,en)-Hi(i,j)*Hi(j,en);
                    zzi=zzi+Hr(i,j)*Hi(j,en)+Hi(i,j)*Hr(j,en);

                }

                yr=xr-Wr[i];
                yi=xi-Wi[i];
                if(yr==0 && yi==0)
                {
                    tst1=norm;
                    yr=tst1;
                    do
                    {
                        yr=0.01*yr;
                        tst2=norm+yr;
                    }while(tst2>tst1);

                }
                Hr(i,en)=(cplx(zzr,zzi)/cplx(yr,yi)).get_real();
                Hi(i,en)=(cplx(zzr,zzi)/cplx(yr,yi)).get_img();
                tr=abs(Hr(i,en))+abs(Hi(i,en));

                if(tr==0)continue;
                tst1=tr;
                tst2=tst1+1/tst1;
                if(tst2>tst1) continue;
                for(j=i;j<=en;j++)
                {
                    Hr(j,en)=Hr(j,en)/tr;
                    Hi(j,en)=Hi(j,en)/tr;

                }
                    
                

                

            }

  }

        for(i=1;i<=n;i++)
        {
            if(i>=1 && i<=n)continue;

            for(j=i;j<=n;j++)
            {
                Zr(i,j)=Hr(i,j);
                Zi(i,j)=Hi(i,j);

            }
            

        }

        for(jj=1;jj<=n;jj++)
        {
            j=n+1-jj;
            if(j<n)
            m=j;
            else
            m=n;

            for(i=1;i<=n;i++)
            {
                zzr=0;
                zzi=0;
                for(k=1;k<=m;k++)
                {
                    zzr=zzr+Zr(i,k)*Hr(k,j)-Zi(i,k)*Hi(k,j);
                    zzi=zzi+Zr(i,k)*Hi(k,j)+Zi(i,k)*Hr(k,j);

                }

                Zr(i,j)=zzr;
                Zi(i,j)=zzi;

            

            
            }
        }

    
    

        
    }

    

 
}
