#include <iostream>
using namespace std;
#include <cmath>
#include "vec.h"
#include "cplx.h"
#include "ing2.h"
#include "StiffIntegratorT.h"
#include "NonStiffIntegratorT.h"
#include "decsol.h"


extern void fx(Vec & v1, Vec & v2, double x, double y);


void Jacobian (double z,double *Fx,double **J, double x)
{
	Vec Cr,Ci; Cr=Ci=Vec(nd,0);
int i,j;


	fx(Cr,Ci,z,x);

	for(i=0;i<nd;i++)
		for(j=0;j<nd;j++)
	{


	J[i][j]=Cr(i+1,j+1);
	J[i+nd][j+nd]=Ci(i+1,j+1);
	}
	
	return;

}




