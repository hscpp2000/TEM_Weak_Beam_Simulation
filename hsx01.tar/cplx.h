#ifndef _CPLX_H_
#define _CPLX_H_
 

class cplx               
{
    private:
     
    double real,img;
    
    public:
    cplx();
    cplx(const double & x, const double & y);
    cplx(const cplx & c);
    ~cplx();
    double modulus();
    cplx  operator+(const cplx & c) const;
    cplx operator-(const cplx & c) const;
    cplx operator-() const;
    cplx operator*(const cplx & c) const;    
    cplx operator/(const cplx & c) const;    
    bool operator==(const cplx & c) const;    
    bool operator!=(const cplx & c) const;    
    cplx operator^(const int & n) const;    
    friend ostream & operator<<(ostream & os, const cplx & );
    cplx & operator=(const cplx &);
    double & get_real();
    double & get_img();
    cplx conj();

    };


    
#endif


 
  
    
 


