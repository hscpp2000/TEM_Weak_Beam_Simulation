// This is an adaptive stepsize control program

#include <iostream>
using namespace std;
#include <cmath>
#include "vec.h"
#include "cplx.h"
#include "ing2.h"


extern void complex_inv(Vec & v1,Vec & v2);
void derivs4(double  z, Vec & fr, Vec & fi,Vec Pr,Vec Pi, double& x,int& iz);
//Vec rotate(Vec & v);
//void complex_inv(Vec & v1, Vec & v2);


void ingfault(Vec& br,Vec& bi, double& x)

{



    Vec Gr(nd*nd,0);
    Vec Gi(nd*nd,0);
    Vec Pr(nd*nd,0);
    Vec Pi(nd*nd,0);
    double z1,z2,z;



    int i1;
    Vec fr(nd*nd,0);Vec fi(nd*nd,0);


//integrating starting and ending points
    z2=thick;z1=0;




//adding increasement
    double ddz= .1;
    int n=fabs(z2-z1)/ddz;
    Vec Br(nd,0);Vec Bi(nd,0);

// calculation of p=exp{2pigamma}dz for a perfect crystal:
//W=Gamma, the eigen factor
     
  for(i1=0;i1<nd;i1++)
  {  Gr[i1*(nd+1)]=cos(Wr[i1]*ddz*2*pi)*exp(-Wi[i1]*ddz*2*pi);
      Gi[i1*(nd+1)]=sin(Wr[i1]*ddz*2*pi)*exp(-Wi[i1]*ddz*2*pi);}





    Pr=(Zr*Gr)*Zi;
    Pi=(Zr*Gi)*Zi;
	Vec P1r,P1i;
	P1r=Pr;P1i=Pi;
	z=0;
	int iz=0;
	
	    for (i1=0;i1<n;i1++)
    {

	z=float(i1)*ddz;        
	derivs4(z,fr,fi,Pr,Pi,x,iz);//fr, fi/Pn=Qn-1PQn 

	Br=P1r*fr-P1i*fi;
	Bi=P1r*fi+P1i*fr; //B=P1*..Pn


        P1r=Br;P1i=Bi;



    }

    br=bi=Vec(nd,0);
    br[0]=1.;

    fr=(Br*br)-(Bi*bi);
      fi=(Br*bi)+(Bi*br);

    br=fr;bi=fi;


//    exit(1);







}



void derivs4(double  z, Vec & fr, Vec & fi,Vec Pr, Vec Pi,double& x,int&iz)
{


    int i1=0;
    double y,y0,y1,y2,y3;
    //double tFNBM=bFNBM/FNBM;

    double ymin=0.0025;


    
    if (ang==1.)
    {

	
	y=c3-z;

	ymin=-1;
    }
    else
    {
   
//	y=ang*(thick-z-u0*tang/FNBM);
y=s4*(c2-z);


	ymin=-s4;

    }





    //     cout<<y<<" "<<iz<<" "<<x<<endl;

    y0=y;
    y=y0+pt1;
    y1=y0+pt2;
    y2=y0-pt2;
    y3=y0+pt3;


    
    double Beta=0;
    
    cplx c10;
    Vec Qr(nd*nd,0);
    Vec Qi(nd*nd,0);
    Vec Qinvr(nd*nd,0);
    Vec Qinvi(nd*nd,0);
    Vec tr(nd*nd,0);Vec ti(nd*nd,0);
    double b1,b2,b3,b4,b5; b1=b2=b3=b4=b5=0;
    double x1a,x1b,x1c,x1d;


    x1a=-(dc1+0.5*da);
    x1b=-(0.5*da);
    x1c=0.5*da;
    x1d=-x1a;






    for (i1=0;i1<nd;i1++)
    {

        if(x<x1a && (y0-ymin)<.2 && iz==0){Beta=(R1)*gvec[i1];}
	if(x>x1a && x<x1b && (y-ymin)<.2 && iz==0){Beta=(R2)*gvec[i1];}
if(x>x1b && x<x1c && (y1-ymin)<.2 && iz==0){Beta=(R3)*gvec[i1];}
if(x>x1c && x<x1d && (y2-ymin)<.2 && iz==0){Beta=(R4)*gvec[i1];}
if(x>x1d && (y3-ymin)<.2 && iz==0){Beta=(R5)*gvec[i1];}




	if(x==1000)Beta=0.;
		if(Beta!=0)
		  {
	Qr[i1*(nd+1)]=cos(Beta);
	Qi[i1*(nd+1)]=sin(Beta);
	c10=cplx(1,0)/cplx(Qr[i1*(nd+1)],Qi[i1*(nd+1)]);
	Qinvr[i1*(nd+1)]=c10.get_real();
	Qinvi[i1*(nd+1)]=c10.get_img();
		  }

    }
    

    // Qinvr=Qr; Qinvi=Qi;


    //complex_inv(Qinvr,Qinvi);
	if(Beta!=0)
	  
	  {
    tr=Qinvr*Pr-Qinvi*Pi;
    ti=Qinvr*Pi+Qinvi*Pr;

    
    fr=tr*Qr-ti*Qi;
    fi=ti*Qr+tr*Qi;


	  Beta=0;iz=1;
	  }
	else
	  {fr=Pr;fi=Pi;}
	
//    tr=(Qinvr|Pr)-(Qinvi|Pi);
//    ti=(Qinvr|Pi)+(Qinvi|Pr);
//    fr=(tr|Qr)-(ti|Qi);
//    fi=(tr|Qi)+(ti|Qr);  //Pn


    


}








 





