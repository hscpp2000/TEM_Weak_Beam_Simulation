#include <iostream>
#include <cmath>


#include <algorithm>
#include <stdio.h>
#include <stdlib.h>

using namespace std;
#include "cplx.h"
#include "vec.h"

double pythag(double a, double b);

void tqli( int & n,Vec & d,Vec & z,double * e)
{

    int i,ii,iter,k,l,m;
    int sw=1;int sw2=0;    
    double b,c,dd,f,g,p,r,s;dd=0;
 
    for (i=2;i<=n;i++)
    {
        e[i-1]=e[i];
    }

    e[n]=0;
    for(l=1;l<=n;l++)
    {
        iter=0;
        while(sw==1)
     {
        sw2=0;
        for(m=l;m<=n-1;m++)
        {
            dd=abs(d[m])+abs(d[m+1]);
            if (abs(e[m])+dd==dd) break;
        }
        if (abs(e[m])+dd!=dd) m=n;
        if (m==l) break;
     
            if (iter==30){cout<<"over 30 iterations!";exit(1);}
            iter++;
            g=(d[l+1]-d[l])/(2*e[l]);
            r=pythag(g,1.);
            g=d[m]-d[l]+e[l]/(g+r*g/abs(g));
            s=1.;
            c=1.;
            p=0;
            for(ii=l;ii<=m-1;ii++)
            {
                i=m-1-ii+l;
                f=s*e[i];
                b=c*e[i];
                r=pythag(f,g);
                e[i+1]=r;
                if(r==0)
                {
                    d[i+1]=d[i+1]-p;
                    e[m]=0;
                    sw2=1;
                }
                if(r==0)break;
                s=f/r;
                c=g/r;
                g=d[i+1]-p;
                r=(d[i]-g)*s+2*c*b;
                p=s*r;
                d[i+1]=g+p;
                g=c*r-b;
                for(k=1;k<=n;k++)
                {
                    f=z(k,i+1);
                    z(k,i+1)=s*z(k,i)+c*f;
                    z(k,i)=c*z(k,i)-s*f;
                }
            }
            if(r==0 && sw2==1)continue;
            d[l]=d[l]-p;
            e[l]=g;
            e[m]=0;
        
     }
    
    }

    
}
