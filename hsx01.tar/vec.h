#ifndef _VEC_H_
#define _VEC_H_
 
class Vec                   
{
    private:
     unsigned int size;   
    double* cube;
    private:

    int sub(const int & n1,const int & n2);
    int sub(const int & n1);

    public:

    Vec();
    Vec(const double & a, const double & b, const double &  c);

    Vec(const double * pt, const unsigned int & n);
    Vec(unsigned int n, double  val=0);
    Vec(const Vec & v);
    ~Vec();

//    void show_tensor();
    void show();
    Vec  operator+(const Vec & v) const;
    Vec operator-(const Vec & v) const;
    Vec operator-() const;
    Vec operator^(const Vec & v) const;
    Vec operator*(const Vec & v) const;    
    double  operator%(const Vec & v) const;
    Vec operator*(const double & a) const;
    Vec operator|(Vec & v);
    double & operator[](int i) const;
     double & operator()(int i, int j);
     double & operator()(int i, int j,int k,int l);
    friend ostream & operator<<(ostream & os, const Vec & v);
    friend istream & operator>>(istream & is,  Vec & v);
    
    Vec & operator=(const Vec &);
    Vec operator/(const Vec & v)const;
    unsigned int len(); 
    Vec operator&(const Vec & v) const;
     
    };


#endif
  //  void t24(const  int & n, int & i1,int & i2, int & i3,int & i4);
//    double nsqrt(double  a, int  n);
//    Vec(const double * pt); 
//    Vec(const Vec & v1,const Vec & v2, const Vec & v3);
//    Vec(const double * p1, const double * p2,  int & n);
//    Vec::Vec(const Vec & v1, const Vec & v2);
//    double det();
//     double mode();
//    void set_tensor(const  double &  val,const  int & n);
//    Vec axis(const Vec & v);
//    Vec extra(const int & n1,const int & n2);
  //  Vec cofactor();
//    Vec inv();
//    Vec rotate();
  //   Vec replace(Vec & v, int n1, int n2);
//     Vec replace_Col(Vec & v, int n1);
//     Vec rec();
 //    Vec get_col(int n1);
//     Vec exc_c(int n1, int n2);
//     Vec exc_r(int n1, int n2);

  
    
 



