#include <iostream>
#include <cmath>

#include <algorithm>
#include <stdio.h>
#include <stdlib.h>

using namespace std;
#include "cplx.h"
#include "vec.h"

double pythag(double a, double b);

void tql2( int & n,Vec & d,Vec & z,double * e)
{

    int i,ii,k,l,m,j,l1,l2,mml;
    int sw=1;
    double c,c2,c3,dl1,el1,f,g,h,p,r,s,s2,tst1,tst2;
   c=c2=c3=dl1=el1=f=g=h=p=r=s=s2=tst1=tst2=0;
    for(i=2;i<=n;i++)
    e[i-1]=e[i];
    f=0;tst1=0;e[n]=0;
  
    for(l=1;l<=n;l++)
    {
        j=0;
         h=abs(d[l])+abs(e[l]);   
        if(tst1<h)tst1=h;
        for(m=l;m<=n;m++)
        {
           tst2=tst1+ abs(e[m]);
            if(tst2==tst1)break;
        }
 
        if (m!=l)
        while(sw==1)
       { 
        if(j==30){cout<<"over 30 iteration quit!";exit(1);}
        j++;
        l1=l+1;
        l2=l1+1;
         g = d[l];
         p = (d[l1] - g) / (2. * e[l]);
         r = pythag(p,1.);
         d[l] = e[l] / (p + r*p/abs(p));
         d[l1] = e[l] * (p + r*p/abs(p));
         dl1 = d[l1];
         h = g - d[l];
         if (l2 <= n) 
          for( i = l2;i<= n;i++)
           d[i] = d[i] - h;
    	    
            f = f + h;
            p = d[m];
         c = 1.;
         c2 = c;
         el1 = e[l1];
         s = 0.0;
         mml = m - l;
         for( ii = 1;ii<= mml;ii++)
         {
            c3 = c2;
            c2 = c;
            s2 = s;
            i = m - ii;
            g = c * e[i];
            h = c * p;
            r = pythag(p,e[i]);
            e[i+1] = s * r;
            s = e[i] / r;
            c = p / r;
            p = c * d[i] - s * g;
            d[i+1] = h + s * (c * g + s * d[i]);

            for( k = 1;k<= n;k++)
            {
               h = z(k,i+1);
               z(k,i+1) = s * z(k,i) + c * h;
               z(k,i) = c * z(k,i) - s * h;
	    }
	 }
	  p = -s * s2 * c3 * el1 * e[l] / dl1;
         e[l] = s * p;
         d[l] = c * p;
         tst2 = tst1 + abs(e[l]);
         if (tst2 <= tst1)break;
       }
           d[l] = d[l] + f;
 
    }

         for( ii = 2;ii<= n;ii++)
         {
         i = ii - 1;
         k = i;
         p = d[i];

         for( j = ii;j<= n;j++)
         {
            if (d[j] >= p) continue;
            k = j;
            p = d[j];
	 }

         if (k == i) continue;
         d[k] = d[i];
         d[i] = p;

         for( j = 1;j<= n;j++)
         {
            p = z(j,i);
            z(j,i) = z(j,k);
            z(j,k) = p;
	 }

	 }


    
    
}
