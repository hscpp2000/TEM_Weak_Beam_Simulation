#include <iostream>
#include <cmath>


#include <algorithm>
#include <stdio.h>
#include <stdlib.h>

using namespace std;
#include "cplx.h"
#include "vec.h"

double pathag(double a, double b);
cplx csqrt(double a, double b);
void comlr2( int & n,Vec & Hr, Vec & Hi, Vec & Wr, Vec & Wi,
Vec & Zr, Vec & Zi, int * imt, int & err)

{
    


    int i,j,k,l,m,en,ii,jj,ll,mm,nn,im1,ip1,itn,its,mp1,enm1,iend;
    double si,sr,ti,tr,xi,xr,yi,yr,zzi,zzr,norm,tst1,tst2,t1,t2;
    si=sr=ti=tr=xi=xr=yi=yr=zzi=zzr=norm=tst1=tst2=t1=t2=0L;
    int sw=0;
    i=j=k=l=m=ii=jj=ll=mm=nn=im1=ip1=itn=its=mp1=enm1=iend=0;
    err=0;
    en=1;
  
 
    for(i=1;i<=n;i++)
    {
        Zr(i,i)=1L;
    }

        iend=n-2;
        
        
            for(ii=1;ii<=iend;ii++)
            {
                i=n-ii;
                ip1=i+1;
                for(k=ip1;k<=n;k++)
                {
                        
                    Zr(k,i)=Hr(k,i-1);
                    Zi(k,i)=Hi(k,i-1);
                }
                
	
                j=imt[i];
		
            if(i==j) continue;
            
                for(k=i;k<=n;k++)
                {
                
                    Zr(i,k)=Zr(j,k);
                    Zi(i,k)=Zi(j,k);
                    Zr(j,k)=0L;
                    Zi(j,k)=0L;
                }
                Zr(j,i)=1L;   

            
            }
         
            en=n;
                tr=0L;
                ti=0L;
                itn=30*n; 
        
    while(en>=1)
    {
     
                its=0;
                enm1=en-1;
   
        while(sw==0)
        {
           
           
            for(ll=1;ll<=en;ll++)
            {
                l=en+1-ll;
                if (l==1)break;
                tst1=abs(Hr(l-1,l-1))+abs(Hi(l-1,l-1))+abs(Hr(l,l))+abs(Hi(l,l));
                tst2=tst1+abs(Hr(l,l-1))+abs(Hi(l,l-1));
                 if (tst2==tst1) break;
            }
               

            if(en==l) break;
        
        
        
              if (itn==0) {cout<<"failed for eigenvalues"<<endl;exit(1);}
            
            
        
            if (its!=10 && its!=20)
            {
                sr=Hr(en,en);
                si=Hi(en,en);
                xr=Hr(enm1,en)*Hr(en,enm1)-Hi(enm1,en)*Hi(en,enm1);
                xi=Hr(enm1,en)*Hi(en,enm1)+Hi(enm1,en)*Hr(en,enm1);
              
                 if (xr!=0|| xi!=0)
                {
                    yr=(Hr(enm1,enm1)-sr)/2L;
                    yi=(Hi(enm1,enm1)-si)/2L;
                    t1=yr*yr-yi*yi+xr;
                    t2=2*yr*yi+xi;
                    zzr=csqrt(t1,t2).get_real();
                    zzi=csqrt(t1,t2).get_img();
                 
                      if(yr*zzr+yi*zzi<0L)
                    {
                        zzr=-zzr;
                        zzi=-zzi;
                    }
                    t1=(cplx(xr,xi)/cplx(yr+zzr,yi+zzi)).get_real();
                    t2=(cplx(xr,xi)/cplx(yr+zzr,yi+zzi)).get_img();
                    xr=t1;xi=t2;
                    sr=sr-xr;
                    si=si-xi;
                }
            }
            else
            {
              
                sr=abs(Hr(en,enm1))+abs(Hr(enm1,en-2));
                si=abs(Hi(en,enm1))+abs(Hi(enm1,en-2));
                
            }
     
           for (i=1;i<=en;i++)
            {
                Hr(i,i)=Hr(i,i)-sr;
                Hi(i,i)=Hi(i,i)-si;
            }
 
            tr=tr+sr;
            ti=ti+si;
            its=its+1;
            itn=itn-1;
           
            xr=abs(Hr(enm1,enm1))+abs(Hi(enm1,enm1));
            yr=abs(Hr(en,enm1))+abs(Hi(en,enm1));
            zzr=abs(Hr(en,en))+abs(Hi(en,en));
            
       
              
            for(mm=l;mm<=enm1;mm++)
            {
           
                m=enm1+l-mm;
              
                if(m==l) break;
                
                   
                    yi=yr;
                    yr=abs(Hr(m,m-1))+abs(Hi(m,m-1));
                    xi=zzr;
                    zzr=xr;
                    xr=abs(Hr(m-1,m-1))+abs(Hi(m-1,m-1));
                    tst1=zzr/yi*(zzr+xr+xi);
                    tst2=tst1+yr;
                
                if (tst2==tst1)break;

            
            }
                
            mp1=m+1;

             for(i=mp1;i<=en;i++)
             {
                im1=i-1;
                xr=Hr(im1,im1);
                xi=Hi(im1,im1);
                yr=Hr(i,im1);
                yi=Hi(i,im1);
                 
                if (abs(xr)+abs(xi)<abs(yr)+abs(yi))
                {
                    for (j=im1;j<=n;j++)
                    {
                        zzr=Hr(im1,j);
                        Hr(im1,j)=Hr(i,j);
                        Hr(i,j)=zzr;
                        zzi=Hi(im1,j);
                        Hi(im1,j)=Hi(i,j);
                        Hi(i,j)=zzi;
                    }
                    zzr=(cplx(xr,xi)/cplx(yr,yi)).get_real();
                    zzi=(cplx(xr,xi)/cplx(yr,yi)).get_img();
                    Wr[i]=1L;
                }
                else
                {
                    zzr=(cplx(yr,yi)/cplx(xr,xi)).get_real();
                    zzi=(cplx(yr,yi)/cplx(xr,xi)).get_img();
                    Wr[i]=-1L;
                }
                 
                Hr(i,im1)=zzr;
                Hi(i,im1)=zzi;

                for(j=i;j<=n;j++)
                {
                    Hr(i,j)=Hr(i,j)-zzr*Hr(im1,j)+zzi*Hi(im1,j);
                    Hi(i,j)=Hi(i,j)-zzr*Hi(im1,j)-zzi*Hr(im1,j);
                }
             }
        
             for(j=mp1;j<=en;j++)
             {
                xr=Hr(j,j-1);
                xi=Hi(j,j-1);
                Hr(j,j-1)=0L;
                Hi(j,j-1)=0L;
         
                if(Wr[j]>0)
                {
                    for (i=1;i<=j;i++)
                    {
                        zzr=Hr(i,j-1);
                        Hr(i,j-1)=Hr(i,j);
                        Hr(i,j)=zzr;
                        zzi=Hi(i,j-1);
                        Hi(i,j-1)=Hi(i,j);
                        Hi(i,j)=zzi;
                    }

                    for (i=1;i<=n;i++)
                    {
                        zzr=Zr(i,j-1);
                        Zr(i,j-1)=Zr(i,j);
                        Zr(i,j)=zzr;
                        zzi=Zi(i,j-1);
                        Zi(i,j-1)=Zi(i,j);
                        Zi(i,j)=zzi;

                    }

                }

                for(i=1;i<=j;i++)
                {
                    Hr(i,j-1)=Hr(i,j-1)+xr*Hr(i,j)-xi*Hi(i,j);
                    Hi(i,j-1)=Hi(i,j-1)+xr*Hi(i,j)+xi*Hr(i,j);

                }
     

                for(i=1;i<=n;i++)
                {
                    Zr(i,j-1)=Zr(i,j-1)+xr*Zr(i,j)-xi*Zi(i,j);
                    Zi(i,j-1)=Zi(i,j-1)+xr*Zi(i,j)+xi*Zr(i,j);
                }
             }
           
        }  
         
        

        Hr(en,en)=Hr(en,en)+tr;
        Wr[en]=Hr(en,en);
        Hi(en,en)=Hi(en,en)+ti;
        Wi[en]=Hi(en,en);
        en=enm1;
               
    }
     
        norm=0L;
        for(i=1;i<=n;i++)
        for(j=i;j<=n;j++)
        {
            tr=abs(Hr(i,j))+abs(Hi(i,j));
            if (tr>norm) norm=tr;
        }

        Hr(1,1)=norm;
     if (n!=1 && norm!=0)
   {
        for(nn=2;nn<=n;nn++)
        {
            en=n+2-nn;
            xr=Wr[en];
            xi=Wi[en];
            Hr(en,en)=1L;
            Hi(en,en)=0L;
            enm1=en-1;
            for(ii=1;ii<=enm1;ii++)
            {
                i=en-ii;
                zzr=0L;
                zzi=0L;
                ip1=i+1;

                for(j=ip1;j<=en;j++)
                {
                    zzr=zzr+Hr(i,j)*Hr(j,en)-Hi(i,j)*Hi(j,en);
                    zzi=zzi+Hr(i,j)*Hi(j,en)+Hi(i,j)*Hr(j,en);

                }

                yr=xr-Wr[i];
                yi=xi-Wi[i];
                if(yr==0 && yi==0)
                {
                    tst1=norm;
                    do
                    {
                     yr=0.01L*yr;
                    tst2=norm+yr;
		    } while (tst2<=tst1);
		}                

		Hr(i,en)=(cplx(zzr,zzi)/cplx(yr,yi)).get_real();
		Hi(i,en)=(cplx(zzr,zzi)/cplx(yr,yi)).get_img();
                tr=abs(Hr(i,en))+abs(Hi(i,en));
                if(tr!=0)
                {
                    tst1=tr;
                    tst2=tst1+1l/tst1;
                    if(tst2<=tst1)
                    {
                        for(j=i;j<=en;j++)
                        {
                            Hr(j,en)=Hr(j,en)/tr;
                            Hi(j,en)=Hi(j,en)/tr;
                        }

                    }

                }
                
            }

        }

        for(jj=1;jj<=n;jj++)
        {
            j=n+1-jj;
            m=j;
            for (i=1;i<=n;i++)
            {
                zzr=0L;
                zzi=0L;
                for (k=1;k<=m;k++)
                {
                    zzr=zzr+Zr(i,k)*Hr(k,j)-Zi(i,k)*Hi(k,j);
                    zzi=zzi+Zr(i,k)*Hi(k,j)+Zi(i,k)*Hr(k,j);
                }

                Zr(i,j)=zzr;
                Zi(i,j)=zzi;

            }

        }

 



   }
    
    
}


double pythag(double a,double b)
{
//     finds dsqrt(a**2+b**2) without overflow or destructive underflow

    double p,r,s,t,u;
    int sw=0;
    if(abs(a)>abs(b))
        p=abs(a);
        else
        p=abs(b);
      
      if (p != 0)
      {
        if(abs(a)<abs(b))
      r = abs(a)/p*abs(a)/p;
        else
        r=abs(b)/p*abs(b)/p;
        while(sw<165000)
        {
         t = 4 + r;
         if (t == 4.) break;
         
         s = r/t;
         u = 1. + 2*s;
         p = u*p;
         r = (s/u)*(s/u) * r;
        sw++;
        if(sw==165000){cout<<"faild in function csqrt()\n";exit(1);}
       }
      }
      
    return p;
}

cplx csqrt(double a, double b)
{
    double yr,yi,tr,ti,s;
    tr=a;
    ti=b;
    s=sqrt(0.5L*(pythag(tr,ti)+abs(tr)));
    if(tr>=0L)yr=s;
    if(ti<0L)s=-s;
    if(tr<=0L)yi=s;
    if(tr<0L)yr=0.5L*(ti/yi);
    if (tr>0L)yi=0.5L*(ti/yr);
   
    return cplx(yr,yi);

}

