//new.cpp including many functions used 
// to replace orginal vector class constructor and
// class member functions to reduce memoery for the class.

#include <iostream>


#include <algorithm>
#include <stdio.h>
#include <stdlib.h>

//#include <cstring>
using namespace std;
#include "vec.h"
//#include "cplx.h"
#include <cmath>
Vec m3(const Vec & v1, const Vec & v2, const Vec & v3);
Vec m2(Vec & v1, Vec & v2);

const double zero=0;
double mode(Vec & v);
void set_tensor(const  double &  val,const  int & n,Vec & v);
void t24(const int & n, int & i1,int & i2,int & i3, int & i4);
Vec axis(Vec & v,Vec & u);
Vec extra(const int & n1, const int & n2,Vec & v);
Vec rotate(Vec & v);
void replace(Vec & v, int n1, int n2,Vec & u);
void replace_Col(Vec & v, int n1,Vec & u);
Vec rec(Vec & v);
Vec get_col(int n1, Vec & v);
void exc_c(int n1, int n2,Vec & v);
void exc_r(int n1, int n2, Vec & v);


//three axis vectors into transfer matrix

Vec m3( Vec & v1, const Vec & v2, const Vec & v3)
{
    unsigned int n;
    n=v1.len();
    
    unsigned int i;
    Vec temp(3*n,0);
    for(i=0;i<n;i++)
    {
        temp[i]=v1[i];
        temp[i+n]=v2[i];
        temp[i+2*n]=v3[i];

    } 
    return temp;
}

Vec m2 (Vec & v1, Vec & v2)
{
    unsigned int n=v2.len();
  unsigned int n1=n*n;

    Vec temp(n1,0);;
    unsigned int  i,j,m,m1,m2;m1=m2=m=0;
    
    for (i=0;i<n;i++)
       for(j=0;j<n;j++)
        if (i==j)
          temp[i*n+j]=v2[i];
          else
        if (i<j)
              {temp[i*n+j]=1/v1[j-i-1];}
                else
               temp[i*n+j]=temp[i+n*j];
    return temp;
}





double mode(Vec & v)
{

    double sum=0;
    for (unsigned int i=0;i<v.len();i++)
    sum=sum+v[i]*v[i];
   return sqrt(sum);
}
void set_tensor(const  double &  val,const  int & n,Vec & v)
{
  if(v.len()!=81)
    {
    cout<<"the input matrix is not a 9 x 9 tensor"<<endl;
    exit(1);
    }
     int id1,id2,id3,id4,m;
    m=0;
    int i,j,k,l,i1,j1,k1,l1;
    t24(n,id1,id2,id3,id4);
   
    for(i=0;i<3;i++)
        for(j=0;j<3;j++)
            for(k=0;k<3;k++)
                for(l=0;l<3;l++)
                    {
                            i1=i+1;j1=j+1;k1=k+1;l1=l+1;
                        if (i1*10+j1==id1 && k1*10+l1==id2)
                            v[m]=val;
                        if (i1*10+j1==id1 && k1*10+l1==id4)
                            v[m]=val;
                        if (i1*10+j1==id3 && k1*10+l1==id4)
                            v[m]=val;
                        if (i1*10+j1==id3 && k1*10+l1==id2)
                            v[m]=val;
                        m++;  
                            
                
                    }
                
        
}
void t24(const int & n, int & i1,int & i2,int & i3, int & i4)
{
int n1,n2;
    n1=n/10;
    n2=n-n1*10;
    int t1[]={11,22,33,32,31,21};
    int t2[]={0,0,0,23,13,12};
    i1=t1[n1-1];
    i2=t1[n2-1];
    i3=t2[n1-1];
    i4=t2[n2-1];
}


Vec axis(Vec & v,Vec & u)
{
    if(v.len()!=9)
        {
            cout<<"the axis matrix is wrong for the tensor axis change";
            exit(1);
        }
    int i,j,k,m,i2,j2,k2,m2;
    int n,n1; n=n1=0;
	double t1[9][9];

    double sum=0;
	for(i=0;i<3;i++)
	for(j=0;j<3;j++)
		{
			t1[i][j]=v[n1];
			n1++;
		}
	n1=0;
    double * temp=new double[u.len()];
    for (i=0;i<3;i++)
      for (j=0;j<3;j++)
        for(k=0;k<3;k++)
          for (m=0;m<3;m++)
            {

              
                   for (i2=0;i2<3;i2++)
		{		
                     for (j2=0;j2<3;j2++)
                       for (k2=0;k2<3;k2++)
                         for(m2=0;m2<3;m2++)
                        {
                           
                                sum=sum+t1[i][i2]*t1[j][j2]*t1[k][k2]
				*t1[m][m2]*u[n1];
                                n1++;
                        }
		}    
	
        	        n1=0;
             temp[n]=sum;sum=0;n++;   
        }
        return Vec(temp,81);
}


Vec extra(const int & n1, const int & n2,Vec & v)
{
        if(v.len()!=81)
        {
            cout<<"the  matrix is wrong for the tensor";
            exit(1);
        }
    double * temp=new double[9];
    int i,j,k,m,i1,j1,k1,m1,m2,m3;
        m2=m3=0;
    for (i=0;i<3;i++)
        for (j=0;j<3;j++)
            for (k=0;k<3;k++)
                for (m=0;m<3;m++)
                {
                    i1=i+1;j1=j+1;k1=k+1;m1=m+1;
                    if (j1==n1 && m1==n2)
                        {
                            temp[m2]=v[m3];
                            m2++;
                              
                        }
                    m3++; 

                }
        return Vec(temp,9);
}

Vec rotate(Vec & v)
{
         int n=(int)sqrt(v.len());
         if (n*n!=(int) v.len())
        {
            cout<<"not a square matrix";
            exit(1);
        }

         double t1[9][9];
        int i,j;
        int m=0;
        for (i=0;i<n;i++)
        for(j=0;j<n;j++)
        {
            
            t1[j][i]=v[m];
            m++;
            
            
        }
            
     //double t2[v.len()];
double t2[999];
     m=0;
    for(i=0;i<n;i++)
     for(j=0;j<n;j++)
     {
        t2[m]=t1[i][j];
        m++;
    }
     
     return Vec(t2,v.len());
     
}


void replace(Vec & v, int n1, int n2,Vec & u)
{
	int i;
	
	for (i=n1;i<n2+1;i++)
	u[i]=v[i];


}


void replace_Col(Vec & v, int n1,Vec & u)
{
	int i,j,m,n;m=0;
	n=(int)sqrt(u.len());
	for (i=0;i<n;i++)
	for (j=0;j<n;j++)
	{
	if (j==n1)
	u[m]=v[m];
	m++;
	}


}


Vec rec(Vec & v)
{
    int n=v.len();
    int i;
    Vec temp(n,0);
    for (i=0;i<n;i++)
    temp[i]=1/v[i];
    return temp;
}



Vec get_col(int n1, Vec & v)
{
    int n=(int )sqrt(v.len());
    int i,j;
    int m=0;
    Vec t1(n,0);
    
    for (i=0;i<n;i++)
    for(j=0;j<n;j++)
    if(j==n1-1)
    {
        t1[m]=v[i*n+j];
        m++;
        

    }
    return t1;
}


void exc_c(int n1, int n2,Vec & v)
{
    int n=(int) sqrt(v.len());
    double t1;
    int i;

    for (i=0;i<n;i++)
    
    {
        t1=v[i*n+n1-1];
        v[i*n+n1-1]=v[i*n+n2-1];
        v[i*n+n2-1]=t1;
    }


}


void exc_r(int n1, int n2, Vec & v)
{
    int n=(int) sqrt(v.len());
    double t1;
    int i;

    for (i=0;i<n;i++)
    
    {
        t1=v[(n1-1)*n+i];
        v[(n1-1)*n+i]=v[(n2-1)*n+i];
        v[(n2-1)*n+i]=t1;
    }


}
