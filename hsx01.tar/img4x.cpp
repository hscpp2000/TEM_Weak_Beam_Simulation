// main program for calculating transmission electron
//microgras based on dynamical scattering theory by Howie et al.
// and elastic theory by Stroh.
//
// In alogorisms the formulas are the forms in the book by
//Hirsch, Howie,.... and Weilan..
//
#include <iostream>
//#include <cstring>
#include <fstream>
using namespace std;
#include "vec.h"
#include "cplx.h"
#include <cmath>
#include "img.h"
#include <iomanip>
#include <omp.h>
double mode(Vec & v);
Vec rotate(Vec & v);
Vec get_col(int n1,Vec & v);
void exc_c(int n1, int n2, Vec & v);
void exc_r(int n1, int n2, Vec & v);
Vec m3(Vec & v1, const Vec & v2, const Vec & v3);


int main()

{
        int i;
        char par[40];	//title for inputs
	char fname[20];
         nd=0;
        thick=51.2;
	double thinnest;		// the thinnest thickness
	double thickest;		//the thickest thickness
	double fi1;
        Vec Beam(1,0,1); 			//beam direction
    	Vec u(1,-1,0); 			//dislocation direction
        Vec b1,b2,b3,b4;		//Burgers vectors
        Vec Ar,Ai;     //complex matrix of potentials
	
        Vec g(2,0,-2);			//diffraction vector
 	dcode[0]=dcode[1]=dcode[2]=dcode[3]=0;// 1/0 with/without dislocations
	Vec foil(1,1,2);		//foil normal
        double E;			// electron energy
	cin>>par>>fname;
	cin>>par>>Ar;			// elatic constants
        cin>>par>>E;
        E=12.26/sqrt(E*1000.)*.1/sqrt(1+0.9788*0.001*E);
        
        gvec=Vec(4,0);       
	cin>>par>>Beam;//Beam direction
	cin>>par>>u;//dislocation line direction
	cin>>par>>gvec;b1=Vec(gvec[0],gvec[1],gvec[2]);b1=b1*(1./gvec[3]);//Burgers vector 1
	cin>>par>>gvec;b2=Vec(gvec[0],gvec[1],gvec[2]);b2=b2*(1./gvec[3]);//Burgers vector 2
	cin>>par>>gvec;b3=Vec(gvec[0],gvec[1],gvec[2]);b3=b3*(1./gvec[3]);//Burgers vector 3
	cin>>par>>gvec;b4=Vec(gvec[0],gvec[1],gvec[2]);b4=b4*(1./gvec[3]);//Burgers vector 4
	cin>>par>>g;dc1=g[0];da=g[1];dc2=g[2];//fault spacings
	cin>>par>>g;//reflection vector
	cin>>par>>foil;//foil normal
	cp1=cp2=cp3=cp4=cq1=cq2=cq3=cq4=cr1=cr2=cr3=cr4=cs1=cs2=cs3=cs4=Vec(3,0);

	if((Beam%u)/mode(Beam)/mode(u)==1.){cout<<" Beam is paraelle to dislocation line!"<<endl;exit(1);}
	if(Beam%g!=0.){cout<<" beam must be perpendicular to g"<<endl;exit(1);}

	if(mode(b1)!=0.)
	{
	  dcode[0]=1;
		cp1=Ar;
	  stroh(Beam,u,b1,g,cp1,cp2,cp3,cp4);
	}

	if(mode(b2)!=0)
	{
	  dcode[1]=1;
		cq1=Ar;
	  stroh(Beam,u,b2,g,cq1,cq2,cq3,cq4);
	}

	if(mode(b3)!=0)
	{
	  dcode[2]=1;
		cr1=Ar;
	  stroh(Beam,u,b3,g,cr1,cr2,cr3,cr4);
	}

	if(mode(b4)!=0)
	{
	  dcode[3]=1;
		cs1=Ar;
	  stroh(Beam,u,b4,g,cs1,cs2,cs3,cs4);
	}





    Vec OX3=u;
    Vec OX1=Beam^u;
    Vec OX2=OX3^OX1;
    
    OX1=OX1*(1/mode(OX1));
    OX2=OX2*(1/mode(OX2));
    OX3=OX3*(1/mode(OX3));

    Vec DC(9,0);
    DC=m3(OX1,OX2,OX3);

    OX1=-(Beam^u);OX2=-Beam;OX3=OX1^OX2;
    OX1=OX1*(1/mode(OX1));
    OX2=OX2*(1/mode(OX2));
    OX3=OX3*(1/mode(OX3));
    Vec DCX(9,0);
    DCX=m3(OX1,OX2,OX3);

    Vec FN,FNX,BM;
    FN=DC*foil;
        FN=FN*(1./mode(FN));
    FNX=DCX*foil;
    FNX=FNX*(1./mode(FNX));
    BM=DC*Beam;
    BM=BM*(1./mode(BM));

    gvec=Vec(5,0);
    Ai=g;     
    cin>>par>>gvec;Ar=Vec(gvec[0],gvec[1],gvec[2]);Ar=Ar*(gvec[3]/gvec[4]);

    R1=Ai%Ar;
    cin>>par>>gvec;Ar=Vec(gvec[0],gvec[1],gvec[2]);Ar=Ar*(gvec[3]/gvec[4]);
        R2=Ai%Ar;
    cin>>par>>gvec;Ar=Vec(gvec[0],gvec[1],gvec[2]);Ar=Ar*(gvec[3]/gvec[4]);

    R3=(Ai%Ar);R3=(R3-double(int(R3)));
	R3=2*pi*R3;

    cin>>par>>gvec;Ar=Vec(gvec[0],gvec[1],gvec[2]);Ar=Ar*(gvec[3]/gvec[4]);
    R4=Ai%Ar;
    cin>>par>>gvec;Ar=Vec(gvec[0],gvec[1],gvec[2]);Ar=Ar*(gvec[3]/gvec[4]);
    R5=Ai%Ar;
    Vec fp1,fp2,fp3;

    cin>>par>>fp1;// fault 1 normal
    cin>>par>>fp2;// fault 2 normal
    cin>>par>>fp3;// fault 3 normal

	double zp1,zp2,zp3;
	fp1=DC*fp1;fp2=DC*fp2;fp3=DC*fp3;fp1=fp1*(1./mode(fp1));        
	fp2=fp2*(1./mode(fp2));        fp3=fp3*(1./mode(fp3));        
	ang=BM[1];
    zp1=sqrt(fp1[0]*fp1[0]+fp1[1]*fp1[1]);
    zp2=sqrt(fp2[0]*fp2[0]+fp2[1]*fp2[1]);
    zp3=sqrt(fp3[0]*fp3[0]+fp3[1]*fp3[1]);
	pt1=-dc1*fp1[0]/zp1/ang;
	pt2=-da*fp2[0]/zp2/ang;
	pt3=-dc2*fp3[0]/zp3/ang;
	
	dc1=(dc1*fp1[1]/zp1);
	da=(da*fp2[1]/zp2);
	dc2=(dc2*fp3[1]/zp3);


     cin>>par>>nd;  //beam number
  
 gvec=Vec(nd,0);    
    cin>>par>>gvec;// considered beams

    Wr=Vec(nd-1,0); Wi=Vec(nd,0); //eigenvalues    
    Zr=Vec(nd-1,0); Zi=Vec(nd,0);     // eigen vectors
    double lau,lpa;
   cin>>par>>lau;//Lau centre
    cin>>par>>lpa;//lattice parameter
        for(i=0;i<nd;i++)
    Wi[i]=gvec[i]*mode(g)*mode(g)*(lau-gvec[i])*E*.5/lpa/lpa;
    short int nb;
    cin>>par>>nb;//image beam


      cin>>par>>Wr;Wr=Wr*2;//extinction distances

     cin>>par>>Zr;Zr=Zr*2;//extinction distance prime
      cin>>par>>thinnest;Zi=Vec(nd,thinnest);// normal absorption
	cin>>par>>thinnest;
	cin>>par>>thickest;
	cin>>par>>width;
	cin>>par>>dz;
        Ar=m2(Wr,Wi);
      Ai=m2(Zr,Zi);

    if (gvec[0]!=0)
    {
        for (i=0;i<nd;i++)
    if(gvec[i]==0)
    { 
   exc_r(1,i+1,Ar);exc_c(1,i+1,Ar);
     exc_r(1,i+1,Ai);exc_c(1,i+1,Ai);
     E=gvec[0];gvec[0]=0;gvec[i]=E;
    }
    }

    for(i=0;i<nd;i++)
       if(nb==int(gvec[i])){nb=i;break;}



    Wr=Vec(nd,0); Wi=Vec(nd,0);Zr=Vec(nd*nd,0);Zi=Vec(nd*nd,0);

    rs(nd,Ar,Wr,Zr);
   // cg(nd, Ar, Ai,Wr, Wi,Zr, Zi);  //finding eigenvalues/vectors in complex
    Zi=((rotate(Zr))*Ai*Zr);
      for(i=1;i<=nd;i++)
      Wi[i-1]=Zi(i,i);
    Zi=rotate(Zr);

//        C3r=Zr;  C3i=Vec (nd*nd,0);  D3r=Zr; D3i=C3i;
int i1=1;
  /*      for (i1=nd;i1<nd*nd;i1++)
        {
                C3r[i1]=C3r[i1]*cos(R3); C3i[i1]=C3r[i1]*sin(-R3);
		D3r[i1]=D3r[i1]*cos(R3);D3i[i1]=D3r[i1]*sin(R3);
        }
        D3r=rotate(D3r);
        D3i=rotate(D3i);*/
//C3r.show();D3r.show();C3i.show();D3i.show();exit(1);



	  double FNBM;
        FNBM=(FN%BM)/mode(FN)/mode(BM);
   
	
    double back=1.;
    double length;

    int j=0;
    u0=0;
    
  if(ang!=0) tang=sqrt(1.-ang*ang)/ang;
    if(ang==0) {cout<<" the dislocation is pararell to the beam";exit(1);}
    if (ang>.9995)  length=thickest*BM[1]/FN[2]/FNBM;
    if(ang<=.9995)length=.5*(thickest+thinnest)/tang;
    //else length=2.*thickest;
	double us=0;
	if(ang!=1) us=(pt1+pt2+pt3)/ang/tang;else  us=(pt1+pt2+pt3);
	//double ut=0;
	if(us!=0)ut=-abs(us);else {length=length+abs(us);ut=abs(pt1+pt2+pt3);}
    //length=.5*(thinnest+thickest)/tang;//BM[1]/FN[2];
//ut=abs(dc1+dc2+da+(pt1+pt2+pt3)*FNX[0]/FNX[1]);
	if (width==0.)width=0.5*length;else length=2*width;
//	if(width<50*(2*dc1+da))width=50.*(2*dc1+da);
    dx=width/double(row);
     double w2=width*.5;	
//    tang=FN[2]/BM[1];



    u1=0.5*(thickest-thinnest)/length;


    	double    fnx=1-FNX[0]*FNX[0];
	 fnx=sqrt(fnx);
	 //length=length+ut*tang;
	ut=fp2[0]/zp2/ang;
	ofstream fout(fname);
	//Vec rint(131328,0);
//	int  i1=0;
	cout<<" TEM image simulation with dynamical and elasticity anisotropy models"<<endl;
	cout<<" 2000.12  hscp2000@yahoo.com"<<endl;

	cout<<" Picture length:"<<length<<" nm"<<endl;
	cout<<" Picture height:"<<.5*length<<" nm"<<endl;
	Vec rint;
	rint=Vec(300000,0);
	double fmax=0;
	Vec br,bi,br2,bi2,br3,bi3,br4,bi4;
	double fmax2=0;
	double fmax3=0;
	double fmax4=0;
	double x,x2,x3,x4;
	int num_threads=4;
	omp_set_num_threads(num_threads);
	int i2=num_threads;

 

while (u0<(length))
    {

	u0=length/512.*double(j);
        thick=thinnest+2.*u0*u1;        
    for(i=0;i<row;i+=i2)
    {
	
#pragma omp parallel private(fi1)
 {
#pragma omp  sections 
{	
#pragma omp section 
    { 
        x=(double)(i)*dx-w2;
        if(i==0 && j==0)x=1000.;   
         ing(br,bi,x);
	br=(br&br)+(bi&bi);
	if(i==0 && j==0)
	{ back=br[0]; }
	fi1=br[nb]/back;
       if(fmax<fi1){fmax=fi1;}
   }
#pragma omp section 
   {    
       x2=(double)(i+1)*dx-w2;
         ing(br2,bi2,x2);
	 br2=(br2&br2)+(bi2&bi2);
	 fi1=br2[nb]/back;
       if(fmax2<fi1){fmax2=fi1;}
   }
#pragma omp section 
   {    
       x3=(double)(i+2)*dx-w2;
         ing(br3,bi3,x3);
	 br3=(br3&br3)+(bi3&bi3);
	 fi1=br3[nb]/back;
       if(fmax3<fi1){fmax3=fi1;}
   }
   
#pragma omp section 
   {    
       x4=(double)(i+3)*dx-w2;
         ing(br4,bi4,x4);
	 br4=(br4&br4)+(bi4&bi4);
	 fi1=br4[nb]/back;
       if(fmax4<fi1){fmax4=fi1;}
   }




}


 }
	rint[i1]=br[nb]/back;
	rint[i1+1]=br2[nb]/back;
	rint[i1+2]=br3[nb]/back;
	rint[i1+3]=br4[nb]/back;
	i1+=i2;


      
            
 
    }

    	

    j++;
	
   }
 if(fmax<fmax2)fmax=fmax2;
 if(fmax<fmax3)fmax=fmax3;
 if(fmax<fmax4)fmax=fmax4;
 
	int nl=j;
	back=0;

	char aint='a';
	i1=0;
	//	ofstream fout(fname);
	for (j=0;j<nl;j++)
	{
		for(i=0;i<256;i++)
	  {
		aint=int(rint[i1]/fmax*255);
		i1++;
		fout<<aint;

	  }
		//	fout<<'\n';
	}

fout.close();
 return 0;
}











