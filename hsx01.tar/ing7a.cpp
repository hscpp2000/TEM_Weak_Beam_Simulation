// This is an adaptive stepsize control program

#include <iostream>
using namespace std;
#include <cmath>
#include "vec.h"
#include "cplx.h"
#include "ing2.h"

double gr(Vec  v1,Vec  v2,Vec  v3, Vec  v4,double & x,double & y);
extern void complex_inv(Vec & v1,Vec & v2);
void derivs7(double  z, Vec & fr, Vec & fi,Vec Pr,Vec Pi, double& x,int& iz);
//Vec rotate(Vec & v);
//void complex_inv(Vec & v1, Vec & v2);


void ing(Vec& br,Vec& bi, double& x)

{



    Vec Gr(nd*nd,0);
    Vec Gi(nd*nd,0);
    Vec Pr(nd*nd,0);
    Vec Pi(nd*nd,0);
    double z1,z2,z;



    int i1;
    Vec fr(nd*nd,0);Vec fi(nd*nd,0);


//integrating starting and ending points
    z2=thick;z1=0;




//adding increasement
    double ddz= 0.001*z2;
    


    int n=fabs(z2-z1)/ddz;
    Vec Br(nd,0);Vec Bi(nd,0);

// calculation of p=exp{2pigamma}dz for a perfect crystal:
//W=Gamma, the eigen factor
     
  for(i1=0;i1<nd;i1++)
  {  Gr[i1*(nd+1)]=cos(Wr[i1]*ddz*2*pi)*exp(-Wi[i1]*ddz*2*pi);
      Gi[i1*(nd+1)]=sin(Wr[i1]*ddz*2*pi)*exp(-Wi[i1]*ddz*2*pi);}





    Pr=(Zr*Gr)*Zi;
    Pi=(Zr*Gi)*Zi;
	Vec P1r,P1i;
	P1r=Pr;P1i=Pi;
	z=0;
	int iz=0;
	
	    for (i1=0;i1<n;i1++)
    {

	z=float(i1)*ddz;        
	derivs7(z,fr,fi,Pr,Pi,x,iz);//fr, fi/Pn=Qn-1PQn 

	Br=P1r*fr-P1i*fi;
	Bi=P1r*fi+P1i*fr; //B=P1*..Pn


        P1r=Br;P1i=Bi;



    }

    br=bi=Vec(nd,0);
    br[0]=1.;

    fr=(Br*br)-(Bi*bi);
      fi=(Br*bi)+(Bi*br);

    br=fr;bi=fi;


//    exit(1);







}



void derivs7(double  z, Vec & fr, Vec & fi,Vec Pr, Vec Pi,double& x,int&iz)
{


    int i1=0;
    double y,y0,y1,y2,y3;
    //double tFNBM=bFNBM/FNBM;

    double x1=-x;


    
    if (ang==1.)
    {

	
	y=c3-z;


    }
    else
    {
   



	y=s4*((c2-s2*u0/s4/FNBM)*s5/s3-z);
	if(c1==0)y=(thick-0.5*c2/FNBM-s1/s3/FNBM*u0-z)/FNBM;

    }







    y0=y;
    y=y0+pt1;
    y1=y0+pt2;
    y2=y0-pt2;
    y3=y0+pt3;


    
    double Beta=0;
    
    cplx c10;
    Vec Qr(nd*nd,0);
    Vec Qi(nd*nd,0);
    Vec Qinvr(nd*nd,0);
    Vec Qinvi(nd*nd,0);
    Vec tr(nd*nd,0);Vec ti(nd*nd,0);
    double b1,b2,b3,b4,b5; b1=b2=b3=b4=b5=0;
    double x1a,x1b,x1c,x1d;
    x1a=x1-(dc1+0.5*da);
    x1b=x1-(0.5*da);
    x1c=x1+0.5*da;
    x1d=x1+dc2+0.5*da;

    if(x1a==0.)x1a=.05*dx;
    if(x1b==0.)x1b=.05*dx;
    if(x1c==0.)x1c=.05*dx;
    if(x1d==0.)x1d=.05*dx;









    for (i1=0;i1<nd;i1++)
    {


	if(dcode[0]==1)
	    b1=gr((cp1*gvec[i1]),(cp2*gvec[i1]),cp3,cp4,x1a,y);
	else
	    b1=0;

	if(dcode[1]==1)
	    b2=gr((cq1*gvec[i1]),(cq2*gvec[i1]),cq3,cq4,x1b,y1);
	else
	    b2=0;
	if(dcode[2]==1)
	    b3=gr((cr1*gvec[i1]),(cr2*gvec[i1]),cr3,cr4,x1c,y2);
	else
	    b3=0;

	if(dcode[3]==1)
	    b4=gr((cs1*gvec[i1]),(cs2*gvec[i1]),cs3,cs4,x1d,y3);
	else
	    b4=0;
	Beta=b1+b2+b3+b4;



	
	
		  
	Qr[i1*(nd+1)]=cos(Beta);
	Qi[i1*(nd+1)]=sin(Beta);
	c10=cplx(1,0)/cplx(Qr[i1*(nd+1)],Qi[i1*(nd+1)]);
	Qinvr[i1*(nd+1)]=c10.get_real();
	Qinvi[i1*(nd+1)]=c10.get_img();
		  

    }
    



    // Qinvr=Qr; Qinvi=Qi;


    //complex_inv(Qinvr,Qinvi);
    //if(Beta!=0)
	  
	  
    tr=Qinvr*Pr-Qinvi*Pi;
    ti=Qinvr*Pi+Qinvi*Pr;

    
    fr=tr*Qr-ti*Qi;
    fi=ti*Qr+tr*Qi;


	  Beta=0;iz=1;
	  
//	else
	//  {fr=Pr;fi=Pi;}
	
//    tr=(Qinvr|Pr)-(Qinvi|Pi);
//    ti=(Qinvr|Pi)+(Qinvi|Pr);
//    fr=(tr|Qr)-(ti|Qi);
//    fi=(tr|Qi)+(ti|Qr);  //Pn


    


}
// gr function to calculate g.R
double gr(Vec v1,Vec v2,Vec v3, Vec v4,double & x,double & y)
{

    double a1,c1,c2,c3,c4,b1,b2,b3,b4,sum;

    int i;
    sum=0;
    a1=x;
    for(i=0;i<3;i++)
    {
        c1=v1[i];c2=v2[i];c3=v3[i];c4=v4[i];
        b3=1/(c3*c3+c4);
        b1=a1*a1*b3;
        b2=a1*c3*b3;

        {
            b4=sqrt(b1-b2*b2);
            sum=sum+(a1*c1-c2*b2)*b3/b4*atan((y+b2)/b4)
            +c2/2*b3*log((y+b2)*(y+b2)+b4*b4);

	    }
/*
	b4=sqrt(b1-b2*b2);
        sum=sum+(a1*c1-c2*b2)*b3/(b4*b4+(y+b2)*(y+b2))
	    +c2*b3*(y+b2)/((y+b2)*(y+b2)+b4*b4);*/

    }

    return sum*pi*2;

}







 





