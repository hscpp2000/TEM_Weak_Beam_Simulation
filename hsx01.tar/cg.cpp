#include <iostream>
#include <iostream>
#include <cmath>
using namespace std;
#include "cplx.h"
#include "vec.h"

void comhes( int & n, Vec & Ar, Vec & Ai,int * imt);
void comlr2( int & n,Vec & v1, Vec & v2,Vec & v3, Vec & v4,Vec & v5, Vec & v6, int * imt, int & err);
//void combak( int & n, Vec & Ar, Vec & Ai,Vec & Zr, Vec & Zi,int * imt);
void corth(int & n, Vec & v1, Vec & v2, double * v3, double * v4);
void comqr2(int & n, Vec & Ar, Vec & Ai,Vec & Zr, Vec & Zi,
            Vec & Wr, Vec & Wi,double * f1, double * f2);
void cortb(int & n,Vec & v1, Vec & v2,Vec & v3, Vec & v4, double * v5, double * v6);


void cg(int & n, Vec & Ar, Vec & Ai,
Vec & Wr,Vec & Wi,Vec & Zr, Vec & Zi)
{
    int err=0;
    double fv2[n+1];
    double fv3[n+1];
	Vec Ar1,Ai1;
// testing data from the book "Linear Alberage"
//    int imt[n+1];
//    double t1[]={1,2,3,1,3,1,2,4,2,1,3,5,1,3,1,5};
//   double t2[]={3,1,2,1,4,2,1,3,3,5,1,2,2,1,4,3};
//    n=4;Ar=Vec(t1,16);Ai=Vec(t2,16);
  
        corth(n,Ar,Ai,fv2,fv3);
	Ar1=Ar;Ai1=Ai;

        comqr2( n, Ar, Ai,Zr, Zi, Wr, Wi,fv2,fv3 );
	cortb(n,Ar1, Ai1,Zr, Zi, fv2, fv3);
   	
    //    comhes(n,Ar,Ai,imt);
    //Ar1=Ar;Ai1=Ai;
  //  comlr2(n,Ar,Ai,Wr,Wi,Zr,Zi,imt,err);
    // 
    // combak(n,Ar1,Ai1,Zr,Zi,imt);
    
    for (err=0;err<n;err++)
    {
        Wr[err]=Wr[err+1];
        Wi[err]=Wi[err+1];
    }


/*        int i,j;
        double max1=0;

        for (i=1;i<=n;i++)
        {
        for (j=1;j<=n;j++)
        max1=max1+Zr(j,i)*Zr(j,i);
        
        max1=sqrt(max1);
        
        for(j=1;j<=n;j++)
        Zr(j,i)=Zr(j,i)/max1;

        max1=0;
        }
*/
  
}


