// This is an adaptive stepsize control program
// using Runge-Kutta method, surprisingly fast! and accurate!!!

#include <iostream>
using namespace std;
#include <cmath>
#include "vec.h"
#include "cplx.h"
#include "ing2.h"




double gr(Vec  v1,Vec  v2,Vec  v3, Vec  v4,double & x,double & y);
void derivs2(double  z, Vec & fr, Vec & fi,Vec Pr,Vec Pi,int & ks, double& x);
//Vec rotate(Vec & v);
//void complex_inv(Vec & v1, Vec & v2);


void ing(Vec& br,Vec& bi, double& x)

{

    Vec Gr(nd,0);
    Vec Gi(nd,0);
    Vec Pr(nd*nd,0);
    Vec Pi(nd*nd,0);
    double z1,z2,z;



    int i,i1;
    Vec fr(nd*nd,0);Vec fi(nd*nd,0);


    z2=u0*u1;z1=-(thick-u0*u1);
    double xa,xb,xc,xd,Beta1;Beta1=0;
	if(dz==0.)dz=0.5;
        nstep=int(thick/dz);

    br=bi=Vec(nd,0);
    br[0]=1.0;
    Vec Br(nd,0);Vec Bi(nd,0);
	z=z1-dz;
    for(i1=0;i1<nd;i1++)
        {  Gr[i1]=cos(Wr[i1]*dz*2*pi)*exp(-Wi[i1]*dz*2*pi);
                 Gi[i1]=sin(Wr[i1]*dz*2*pi)*exp(-Wi[i1]*dz*2*pi);}





    Pr=(Zr|Gr)*Zi;
    Pi=(Zr|Gi)*Zi;
    xa=-abs(dc1+0.5*da);xb=-.5*abs(da);
    xd=0.5*abs(da+dc2); xc=-xb;
	Vec P1r,P1i;
	P1r=Pr;P1i=Pi;
	int ks=0;
    for(i=1;i<=nstep;i++)
    {
        z=z+dz;

	ks=i;

	derivs2(z,fr,fi,Pr,Pi,ks,x);//f=Pn=Qn-1PQn 
	P1r=fr;
	P1i=fi;

        if(i==nf)
	  {
	if(x<xa )Beta1=2*pi*R1;
	if(x>xa && x<xb )Beta1=2*pi*R2;
	if(x>xb && x<xc ){Beta1=2*pi*R3;}
	if(x>xc && x<xd ) Beta1=2*pi*R4;
	if(x>xd ) Beta1=2*pi*R5;
	  
	    for (i1=1;i1<=nd;i1++)
	     {
	    P1r[i1]=fr[i1]*cos(Beta1)-fi[i1]*sin(Beta1);
	    P1i[i1]=fi[i1]*cos(Beta1)+fr[i1]*sin(Beta1);

	     }

	  }

 	
	Beta1=0;




	Br=(P1r*br)-(P1i*bi); //Un=PnUn-1
        Bi=(P1r*bi)+(P1i*br);


        br=Br;bi=Bi;



        
    }



    fr=(Pr*br)-(Pi*bi);
      fi=(Pr*bi)+(Pi*br);

    // br=fr;bi=fi;



    

}


   	
void derivs2(double  z, Vec & fr, Vec & fi,Vec Pr, Vec Pi,int & ks,double& x)
{
    int i1=0;
    double y,y0,zz;
double y1,y2,y3;

 double tFNBM=bFNBM/FNBM;
 if (ang==1.)
   {
   y=-(z+.5*(thick-u0*u1));
   //   zz=.5*(thick-u0*u1);
   
   }
    else
  {
   
    y=(u0*(tFNBM+tang)/(1-tFNBM*tang)-u0*tFNBM+z)*(FNBM*ang-bFNBM*bng);

    //   zz=(u0*(tFNBM+tang)/(1-tFNBM*tang)-u0*tFNBM);
    
 } 
 y0=y;
 y=y0+pt1;
 y1=y0+pt2;y2=y0-pt2;
 y3=y0+pt3;

    double x1=-x;

    double Beta=0.;
	
    cplx c1;
    Vec Qr(nd,0);
    Vec Qi(nd,0);
    Vec Qinvr(nd,0);
    Vec Qinvi(nd,0);
    Vec tr(nd*nd,0);Vec ti(nd*nd,0);

	double b1,b2,b3,b4; b1=b2=b3=b4=0;
	double x1a,x1b,x1c,x1d;
	x1a=x1-(dc1+0.5*da);
	x1b=x1-(0.5*da);
        x1c=x1+0.5*da; 
	x1d=x1+0.5*da+dc2;
	if(x1a==0.)x1a=.05*dx;
	if(x1b==0.)x1b=.05*dx;
	if(x1c==0.)x1c=.05*dx;	
	if(x1d==0.)x1d=.05*dx;
	x1a=x1a/FB;
	x1b=x1b/FB;
	x1c=x1c/FB;
	x1d=x1d/FB;


             for (i1=0;i1<nd;i1++)
             {
                if(dcode[0]==1) 
		b1=gr((cp1*gvec[i1]),(cp2*gvec[i1]),cp3,cp4,x1a,y);
		else 
		b1=0;
		

                if(dcode[1]==1) 
		b2=gr((cq1*gvec[i1]),(cq2*gvec[i1]),cq3,cq4,x1b,y1);
		else 
		b2=0;
                if(dcode[2]==1)
		b3=gr((cr1*gvec[i1]),(cr2*gvec[i1]),cr3,cr4,x1c,y2);
		else
		b3=0;
                if(dcode[3]==1)b4=
                gr((cs1*gvec[i1]),(cs2*gvec[i1]),cs3,cs4,x1d,y3);
	        Beta=b1+b2+b3+b4;




	

		Qr[i1]=cos(Beta);
		Qi[i1]=sin(Beta);
		    c1=cplx(1,0)/cplx(Qr[i1],Qi[i1]);
		    Qinvr[i1]=c1.get_real();
                    Qinvi[i1]=c1.get_img();
     
           }


	    


	
    tr=(Qinvr|Pr)-(Qinvi|Pi);
    ti=(Qinvr|Pi)+(Qinvi|Pr);
    fr=(tr|Qr)-(ti|Qi);
    fi=(tr|Qi)+(ti|Qr);


	//	{  ks=1;}


}



// gr function to calculate g.R
double gr(Vec v1,Vec v2,Vec v3, Vec v4,double & x,double & y)
{


    double a1,c1,c2,c3,c4,b1,b2,b3,b4,sum;

    int i;
    sum=0;
    a1=x;
    for(i=0;i<3;i++)
    {
        c1=v1[i];c2=v2[i];c3=v3[i];c4=v4[i];
        b3=1/(c3*c3+c4);
        b1=a1*a1*b3;
        b2=a1*c3*b3;
/*        if(a1==0)
        {
            if(y==0)y=0.0000001;
         if (y>0)
	  sum=sum+c2/(c3*c3+c4)*log(abs(y));
        	else sum=sum+c2/(c3*c3+c4)*(-1)*log(-y);
        }
        else*/

        {
            b4=sqrt(b1-b2*b2);
            sum=sum+(a1*c1-c2*b2)*b3/b4*atan((y+b2)/b4)
            +c2/2*b3*log((y+b2)*(y+b2)+b4*b4);

        }
       
       
    }

 return sum;


}




 





