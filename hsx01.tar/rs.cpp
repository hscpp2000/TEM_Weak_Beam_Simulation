#include <iostream>
#include <cmath>
using namespace std;
#include "cplx.h"
#include "vec.h"

void tred2( int & n,Vec & a, Vec & w,Vec & z,double * fv1);
void tql2( int & n,Vec & w, Vec & z,double * fv1);
void tqli( int & n,Vec & w, Vec & z,double * fv1);
void rs(int & n,Vec & a,Vec & w,Vec & z)
{
    double fv1[n+1];
        Vec w0(n+1,0);
    
        tred2(n,a,w0,z,fv1);

       tqli(n,w0,z,fv1);
       int i;
       for(i=0;i<n;i++)
       w[i]=w0[i+1];
    
}

