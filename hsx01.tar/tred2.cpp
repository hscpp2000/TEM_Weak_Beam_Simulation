#include <iostream>
#include <cmath>
using namespace std;
#include "cplx.h"
#include "vec.h"

void tred2( int & n,Vec & a, Vec & d,Vec & z,double * e)
{

    int i,ii,j,k,l;
    i=j=0;
    double f,g,h,hh,scale;

    for (ii=2;ii<=n;ii++)
    {
        i=n-ii+2;    
        l=i-1;

        h=0;
        scale=0;
        if(l>1)
        {
   
           for(k=1;k<=l;k++)
            scale=scale+abs(a(i,k));
         
            if(scale==0)
                e[i]=a(i,l);
            else
            {
                for(k=1;k<=l;k++)
                {   
                a(i,k)=a(i,k)/scale;
                h=h+a(i,k)*a(i,k);
                }

                f=a(i,l);
                g=-sqrt(h)*f/abs(f);
                
                    e[i]=scale*g;
                    h=h-f*g;
                    a(i,l)=f-g;
                    f=0;
                 for (j=1;j<=l;j++)
                    {
                        a(j,i)=a(i,j)/h;
                        g=0;
                    for(k=1;k<=j;k++)
                     g=g+a(j,k)*a(i,k);
                     
                    for(k=j+1;k<=l;k++)
                    g=g+a(k,j)*a(i,k);
                     
                    e[j]=g/h;
                    f=f+e[j]*a(i,j);
                    }

                    hh=f/(h+h);
                    for(j=1;j<=l;j++)
                    {
                    f=a(i,j);
                    g=e[j]-hh*f;
                    e[j]=g;
                            for(k=1;k<=j;k++)
                         a(j,k)=a(j,k)-f*e[k]-g*a(i,k);
                    }
            }
	}
                  else
                e[i]=a(i,l);
          
            d[i]=h;
	
    }
  
    d[1]=0;
    e[1]=0;
    for(i=1;i<=n;i++)
    {
        l=i-1;
        if(d[i]!=0)
        {
            for(j=1;j<=l;j++)
            {
                g=0;
                for(k=1;k<=l;k++)
                g=g+a(i,k)*a(k,j);
                for(k=1;k<=l;k++)
                a(k,j)=a(k,j)-g*a(k,i);
            }
        }
        d[i]=a(i,i);
        a(i,i)=1;
            for(j=1;j<=l;j++)
            a(i,j)=a(j,i)=0;
       
    }

    z=a; 
 
}

