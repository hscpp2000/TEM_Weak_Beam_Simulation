// This is an adaptive stepsize control program

#include <iostream>
using namespace std;
#include <cmath>
#include "vec.h"
#include "cplx.h"
#include "ing2.h"





void derivs4(double  z, Vec & fr, Vec & fi,Vec Pr,Vec Pi, double& x);
//Vec rotate(Vec & v);
//void complex_inv(Vec & v1, Vec & v2);


void ingfault(Vec& br,Vec& bi, double& x)

{

    Vec Gr(nd,0);
    Vec Gi(nd,0);
    Vec Pr(nd*nd,0);
    Vec Pi(nd*nd,0);
    double z1,z2,z;



    int i,i1;
    Vec fr(nd*nd,0);Vec fi(nd*nd,0);





    z2=u0*u1;z1=-(thick-u0*u1);
    double ddz=1.;
    int n=int((z2-z1)/ddz);


    br=bi=Vec(nd,0);
    br[0]=1.0;

    z=z1-ddz;
// calculation of p=exp{2pigamma}dz     
    for(i1=0;i1<nd;i1++)
    {  Gr[i1]=cos(Wr[i1]*ddz*2*pi)*exp(-Wi[i1]*ddz*2*pi);
    Gi[i1]=sin(Wr[i1]*ddz*2*pi)*exp(-Wi[i1]*ddz*2*pi);}


    Vec Mr(nd*nd,0); Vec Mi(nd*nd,0);


    Pr=(Zr|Gr)*Zi;
    Pi=(Zr|Gi)*Zi;
     

    for(i=0;i<n;i++)
    {
        z=z1+float(i)*ddz;
	derivs4(z,fr,fi,Pr,Pi,x);//Pn=Qn-1PQn 

	Mr=Pr*fr-Pi*fi;
	Mi=Pr*fi+Pi*fr;
	Pr=Mr;Pi=Mi;

        
    }


    br=Pr*br;bi=Pi*bi;
    



    

}



void derivs4(double  z, Vec & fr, Vec & fi,Vec Pr, Vec Pi,double& x)
{
    int i1=0;
    double y,y0,y1,y2,y3;
    double tFNBM=bFNBM/FNBM;

    double ymin=0.0025;

    double x1=-x;
    
    if (ang==1.)
    {
	y=-FNBM*(z+.5*thick);
   
    }
    else
    {
   
	y=(u0*(tFNBM+tang)/(1-tFNBM*tang)-u0*tFNBM+z)*(FNBM*ang-bFNBM*bng);
	ymin=fabs(-u0*(tFNBM+tang)/(1-tFNBM*tang)+u0*tFNBM);

    }
 
    y0=y;
    y=y0+pt1;
    y1=y0+pt2;
    y2=y0-pt2;
    y3=y0+pt3;


    double Beta=0;
    
    cplx c1;
    Vec Qr(nd,0);
    Vec Qi(nd,0);
    Vec Qinvr(nd,0);
    Vec Qinvi(nd,0);
    Vec tr(nd*nd,0);Vec ti(nd*nd,0);
    int ip=0;
    double b1,b2,b3,b4,b5; b1=b2=b3=b4=b5=0;
    double x1a,x1b,x1c,x1d;



    x1a=-(dc1+0.5*da);
    x1b=-(0.5*da);
    x1c=0.5*da;
    x1d=-x1a;

    





    for (i1=0;i1<nd;i1++)
    {
	if(x<x1a && fabs(fabs(z)-ymin)<.5)b1=(g%R1)*gvec[i1];
	if(x>x1a && x<x1b && fabs(fabs(z)-ymin)<.4)b2=(g%R2)*gvec[i1];
	if(x>x1b && x<x1c && fabs(fabs(z)-ymin)<.4)
	{b3=(g%R3)*gvec[i1];
	}
if(x>x1c && x<x1d && fabs(fabs(z)-ymin)<.4)b4=(g%R4)*gvec[i1];
	if(x>x1d && fabs(fabs(z)-ymin)<.4)b5=(g%R5)*gvec[i1];



	Beta=b1+b2+b3+b4+b5;


	Qr[i1]=cos(Beta);
	Qi[i1]=sin(Beta);
	c1=cplx(1,0)/cplx(Qr[i1],Qi[i1]);
	Qinvr[i1]=c1.get_real();
	Qinvi[i1]=c1.get_img();
	Beta=b1=b2=b3=b4=b5=0;

    }





    
    tr=(Qinvr|Pr)-(Qinvi|Pi);
    ti=(Qinvr|Pi)+(Qinvi|Pr);
    fr=(tr|Qr)-(ti|Qi);
    fi=(tr|Qi)+(ti|Qr);


    


}








 





